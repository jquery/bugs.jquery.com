//************************************
//**   jquery page specific rules   **
//************************************

$(document).ready(function()
{
	$('#advertisement_holder').appendTo('#advertisement');
	$('#advertisement_holder').css('display', 'block');
});
