<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Test</title>
<script type="text/javascript" src="jquery.js"></script>
<script type="text/javascript">
var remote_server = 'brandon.box.net';

$(function() {
	var url = '/jquery-bug-ie6/ajax.php';
	$.ajax({
		url: 'http://' + remote_server + url
		,dataType: 'jsonp'
		,jsonp: 'jsonp'
	});
});
</script>
</head>
<body>
hello world
</body>
</html>
