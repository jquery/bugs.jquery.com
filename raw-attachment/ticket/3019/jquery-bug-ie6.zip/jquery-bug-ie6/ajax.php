<?php
header('Content-Type: application/x-javascript');
header('Cache-control: no-store');
echo 'alert(\'hello world - ajax.php\');';