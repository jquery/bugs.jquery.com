$(function()
{
	$("#select_all")
		.click(function() 
		{
			$("input[@type=checkbox]")
				.not("#select_all")
				.attr("checked", this.checked)
		});

	$("input")
		.not("#select_all")
		.click(function() 
		{
			$('#select_all')
				.attr(
					'checked', 
					(
						$("input[@type=checkbox]")
							.not("#select_all")
							.not(':checked')
							.length
					? 
						false 
					:
						true
					)
				)

		});
});