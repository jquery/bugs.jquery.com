$(function(){
	$('div.item1').find('img.grey').hide()
	
	var pics2 = $('div.item2').find('img')
	
	$(pics2).find('.grey').hide()
	
	var pics3 = $('div.item3').find('img')
	
	$('.grey', $(pics3)).find('.grey').hide()
})