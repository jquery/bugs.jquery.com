
$(document).ready(function() {

	generateDynamicControls("#xforms_cntrl_AnnexesTrans",
			"#xforms_cntrl_AnnexesTransUnselected", 
			"#xforms_cntrl_AnnexesTransSelected");
	
});
