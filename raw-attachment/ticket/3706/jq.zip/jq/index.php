<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Jquery Validation</title>
</head>
<!-- Include jQuery -->
		<script src="jquery.js" type="text/javascript" charset="utf-8"></script>	
		
		<!-- Include Core Datepicker JavaScript -->
		<script src="jquery.Form.js" type="text/javascript" charset="utf-8"></script>	
		
		<!-- Attach the datepicker to dateinput after document is ready -->
		<script type="text/javascript" charset="utf-8">
			jQuery(function($){
				$("#fmNew").Form();
			});
		</script>
<body>
<form id="fmNew" action="" method="post" enctype="multipart/form-data" target="_self">

<p>&nbsp;</p>
<p>&nbsp;</p>
<table width="60%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td>Name</td>
    <td>&nbsp;</td>
    <td><input name="name2" type="text" class="textfield" id="name2" title="Name" alt="required" /></td>
  </tr>
  <tr>
    <td>Email</td>
    <td>&nbsp;</td>
    <td><input name="email2" type="text" class="textfield" id="email2" title="Email" alt="required||email" /></td>
  </tr>
  <tr>
    <td>Job</td>
    <td>&nbsp;</td>
    <td><input name="job2" type="text" class="textfield" id="job2" title="Job" alt="required" /></td>
  </tr>
  <tr>
    <td>Mobile</td>
    <td>&nbsp;</td>
    <td><input name="mob2" type="text" class="textfield" id="mob2" title="Mobile" alt="required" /></td>
  </tr>
  <tr>
    <td>Number</td>
    <td>&nbsp;</td>
    <td><input name="mob2" type="text" class="textfield" id="mob2" title="Number" alt="required||number" /></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><input type="submit" name="Submit2" value="Submit" /></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
<p>&nbsp;</p>
</form>
</body>
</html>
