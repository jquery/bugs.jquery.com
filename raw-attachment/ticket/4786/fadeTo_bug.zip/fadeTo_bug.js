jQuery(document).ready(function(){

	jQuery('.roundedBox')
		// add to the front inside the box
		.prepend(
			'<div class="corner topLeft"></div>' +
			'<div class="corner topRight"></div>'
		)
		// append to the back inside the box
		.append(
			'<div class="corner bottomLeft"></div>' + 
			'<div class="corner bottomRight"></div>'
		);
	jQuery('.roundedShadow')
		// wrap with balanced pair, or set of tags
		.wrapInner(
			'<div class="sides"></div>'
		)
		// add to the front inside the box
		.prepend(
			'<div class="shadowCorner topLeft"></div>' +
		    '<div class="shadowCorner topRight"></div>'
	    )
	    // append to the back inside the box
		.append(
			'<div class="bottom"></div>' + 
		    '<div class="shadowCorner bottomLeft"></div>' +
		    '<div class="shadowCorner bottomRight"></div>'
		);
	jQuery('.mixedBkgd')
		// add to the front inside the box
		.prepend(
			'<div class="mixedCorner topLeft"></div>' +
			'<div class="mixedCorner topRight"></div>'
		)
		// append to the back inside the box
		.append(
			'<div class="mixedCorner bottomLeft"></div>' + 
			'<div class="mixedCorner bottomRight"></div>'
		);
	jQuery('.roundedShadowMixed')
		// wrap with balanced pair, or set of tags
		.wrapInner(
			'<div class="rsmContent"></div>'
		)
		// add to the front inside the box
		.prepend(
			'<div class="rsmCorner topLeft"></div>' +
			'<div class="rsmCorner topRight"></div>' +
			'<div class="rsmTop"></div>'
	    )
	    // append to the back inside the box
		.append(
			'<div class="rsmBottom"></div>' +
			'<div class="rsmCorner bottomLeft"></div>' +
			'<div class="rsmCorner bottomRight"></div>'
		)
		// fade to some percentage
		.fadeTo(1600, 0.30, function() {
			// decrease fade on mouseenter
			jQuery(this).mouseenter(function(event) {
				jQuery(this).fadeTo('slow', 0.70);
			});
			// increase fade on mouseleave
			jQuery(this).mouseleave(function(event) {
				jQuery(this).fadeTo('slow', 0.30);
			});
		});
	
});

