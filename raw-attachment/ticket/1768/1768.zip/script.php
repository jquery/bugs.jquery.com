<?php
  if (isset($_REQUEST['to'])) {
    sleep($_REQUEST['to']);
  }
  echo '$("#adiv").text("executed!");';
?>

