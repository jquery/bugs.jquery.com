<?php
  if (isset($_REQUEST['to'])) {
    sleep($_REQUEST['to']);
  }
  echo $_REQUEST['callback'] . "({ data: 'jsonp!' })";
?>


