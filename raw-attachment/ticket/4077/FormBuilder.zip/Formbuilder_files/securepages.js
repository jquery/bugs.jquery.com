if (Drupal.jsEnabled) {
    /*$(document).ready(function(){
   
    $("div#quote").load("https://localhost/jnj/test/txtfile.php");
   
    });*/

  $(document).ready(function() {
    var addtional_fields = '';
    var idcount =Drupal.settings.securepages.idcount;
    var var_remove =Drupal.settings.securepages.remove;
    var lable_source = Drupal.settings.securepages.lable_source;
    var lable_dest = Drupal.settings.securepages.lable_dest;
    var desc_source = Drupal.settings.securepages.desc_source;
    var desc_dest = Drupal.settings.securepages.desc_dest;
    for(var i=1; i < Drupal.settings.securepages.source.length; i++) {
      id = i;
      var source_val = Drupal.settings.securepages.source[i];
      var dest_val = Drupal.settings.securepages.dest[i];

      if (source_val != 'undefined' && dest_val != 'undefined') {
        // What changes made in addtional_fields variable values
        // shoule be do again in the another addtional_fields variable in this
        // js file behaviors secion.
        addtional_fields += '\n';
        addtional_fields += '<div id="edit-source-hr-'+id+'" class="form-securepage-hr">\n';
        addtional_fields += '<hr />\n';
        addtional_fields += '</div>\n';
        addtional_fields += '<div id="edit-source-wrapper-'+id+'" class="form-item">\n';
        addtional_fields += '<label for="edit-source-'+id+'">'+lable_source+' ('+id+'): </label>\n';
        addtional_fields += '<input id="edit-source-'+id+'" class="form-text" type="text" value="'+source_val+'" size="60" name="securepages_source'+id+'" maxlength="128"/>\n';
        addtional_fields += '<div class="description">'+desc_source+'</div>'
        addtional_fields += '</div>\n';
        addtional_fields += '<div id="edit-dest-wrapper-'+id+'" class="form-item">\n';
        addtional_fields += '<label for="edit-dest-'+id+'">'+lable_dest+' ('+id+'): </label>\n';
        addtional_fields += '<input id="edit-dest-'+id+'" class="form-text" type="text" value="'+dest_val+'" size="60" name="securepages_dest'+id+'" maxlength="128"/>\n';
        addtional_fields += '<input type="button" class="form-remove" onclick="removeFields(\''+id+'\')" value="'+var_remove+'" />\n';
        addtional_fields += '<div class="description">'+desc_dest+'</div>\n';
        addtional_fields += '</div>\n';
      }
    }
    try {
      document.getElementById('edit-idcount').value =idcount;
    }
    catch(e){}
    $('#additional-fields').append(addtional_fields);
  });
}

/**
 * Show/hide System Prompt options.
 */
Drupal.behaviors.securepages = function() {
  $('input[id=edit-addnew]').click(function() {
    var id = parseInt(document.getElementById('edit-idcount').value);
    var var_remove = Drupal.settings.securepages.remove;
    var addtional_fields = '';
    var lable_source = Drupal.settings.securepages.lable_source;
    var lable_dest = Drupal.settings.securepages.lable_dest;
    var desc_source = Drupal.settings.securepages.desc_source;
    var desc_dest = Drupal.settings.securepages.desc_dest;

    // Constructs the Redirection URL (Source and Destination)

    // What changes made in addtional_fields variable values
    // shoule be do again in the another addtional_fields variable in this
    // js file document ready secion.
    addtional_fields += '\n';
    addtional_fields += '<div id="edit-source-hr-'+id+'" class="form-securepage-hr">\n';
    addtional_fields += '<hr />\n';
    addtional_fields += '</div>\n';
    addtional_fields += '<div id="edit-source-wrapper-'+id+'" class="form-item">\n';
    addtional_fields += '<label for="edit-source-'+id+'">'+lable_source+' ('+id+'): </label>\n';
    addtional_fields += '<input id="edit-source-'+id+'" class="form-text" type="text" value="" size="60" name="securepages_source'+id+'" maxlength="128"/>\n';
    addtional_fields += '<div class="description">'+desc_source+'</div>'
    addtional_fields += '</div>\n';
    addtional_fields += '<div id="edit-dest-wrapper-'+id+'" class="form-item">\n';
    addtional_fields += '<label for="edit-dest-'+id+'">'+lable_dest+' ('+id+'): </label>\n';
    addtional_fields += '<input id="edit-dest-'+id+'" class="form-text" type="text" value="" size="60" name="securepages_dest'+id+'" maxlength="128"/>\n';
    addtional_fields += '<input type="button" class="form-remove" onclick="removeFields(\''+id+'\')" value="'+var_remove+'" />\n';
    addtional_fields += '<div class="description">'+desc_dest+'</div>\n';
    addtional_fields += '</div>\n';

    $('#additional-fields').append(addtional_fields);
    document.getElementById('edit-idcount').value = parseInt(id)+1;
    // To avoid Drupal button submits the form
      return false;
  });
  // To submit the form
  $('input[id=edit-submit]').click(function() {
    $('form[id=securepages-settings]').submit(function() {
      return true;
    });
  });
};
// To Remove the Redirection url fields.
function removeFields(field_id) {
  $('#edit-source-hr-'+field_id).remove();
  $('#edit-source-wrapper-'+field_id).remove();
  $('#edit-dest-wrapper-'+field_id).remove();
}