
$(document).ready(function(){

	var MyOpacity=0.5

	//ONLOAD
	$("#lien2").css("background","#000"); //transparence
	$("#lien2").fadeTo("fast",MyOpacity)
	$("#lien").css("border","solid 1px #000"); //pour les border
	$("#lien_barre").css("border-bottom","solid 1px #000"); //pour les barres de titre (border-bottom)
	$("#lien").draggable({handle:"#lien_barre",containment:"document",zIndex:1,cursor:"move"});
	$("#lien").resizable({transparent:true,handles:"all",containment:"document",minWidth:10,minHeight:10});

	//HOVER
	$("#lien1").hover(
		function (){
			//$(this).prev().css("background",color1).fadeTo("fast",1);
			$(this).prev().fadeTo("fast",1);
			$(this).css("overflow-y","auto")
		},
		function (){
			//$(this).prev().css("background",color1)
			//$(this).css({filter:"alpha(opacity="+MyOpacity1+")",opacity:MyOpacity1/100});
			$(this).prev().fadeTo("fast",MyOpacity)
			$(this).css("overflow-y","hidden")
		}
	);

});
