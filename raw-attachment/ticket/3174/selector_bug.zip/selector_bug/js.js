$(document).ready(function(){
	$("#the_source").click(function(){
		$("#target_container").html($("#source_container").html());
		spot_on("#target_container div");
	});
	spot_on("#source_container");
	
	$("#the_source2").click(function(){
		$("#target_container2").html($("#source_container2").html());
		spot_on("#target_container2 div[extra_tag]");
	});
	spot_on("#source_container2 div[extra_tag]");
	
	$("#the_source3").click(function(){
		$("#target_container3").html($("#source_container3").html());
		spot_on("#target_container3 div[extra_tag='pie']");
	});
	spot_on("#source_container3 div[extra_tag='pie']");

	$("#the_source4").click(function(){
		$("#target_container4").html($("#source_container4").html());
		spot_on("#target_container4 div[class='pie']");
	});
	spot_on("#source_container4 div[class='pie']");

	$("#the_source5").click(function(){
		$("#target_container5").html($("#source_container5").html());
		if ($.browser.msie) 
			spot_on_msie("#target_container5 div[extra_tag='cheese']");
		else
			spot_on("#target_container5 div[extra_tag='cheese']");
	});
	if ($.browser.msie) 
		spot_on_msie("#source_container5 div[extra_tag='cheese']");
	else
		spot_on("#source_container5 div[extra_tag='cheese']");
});

function spot_on(selector) {
	$(selector).hover(function(){
		$(selector).css("backgroundColor", "yellow");
	}, function(){
		$(selector).css("backgroundColor", "");
	});
}

function spot_on_msie(selector) {
	$(selector).each(function(){
	  	this.onmouseenter=function(){
			$(selector).css("backgroundColor", "yellow");
	  	};
		this.onmouseleave=function(){
			$(selector).css("backgroundColor", "");
	  	};
	});	
}
