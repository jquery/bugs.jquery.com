$(function() {
	$.build = {};
    $.extend($.build , {
	setup: function() {
          $("#content").load("external.html",function() {alert('loaded');});
        }
	});
    $.build.setup();
});