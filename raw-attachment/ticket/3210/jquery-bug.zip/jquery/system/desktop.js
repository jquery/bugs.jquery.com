/**
*	Make New Windows
**/
var windows = 0;
function newWindow( xml,template ) {
	$('#desktop').ajaxTransform( xml,template );
	$('#desktop div.window:last').attr('id','window-' + windows );
	$('#window-' + windows )
		.draggable({
			handle: $('#window-' + windows + ' div.head h3'),
			helper: 'clone'
		})
/*
		.resizable({
			proportionallyResize: ['.contentblock'],
			autohide: true
		})
*/
		.find('div.head img.window-min').click( function(){
			$(this).parent().parent().hide();
		})
		.next().click( function(){
			$(this).parent().parent().remove();
		});

	windows++;
}