/**
	Mostly contains misc shit and bug fixes
**/

/**
*	Fix for jQuery document.body not set in XML documents (firefox 3 at least...)
**/
if( document.body == undefined )
	document.body = document.getElementsByTagName('body')[0];
