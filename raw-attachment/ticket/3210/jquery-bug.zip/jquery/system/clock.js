function Clock()
{
	// Clockage	
	this.clockID = 0;

	this.UpdateClock = function()
	{
		if( this.clockID )
		{
			clearTimeout( this.clockID );
			this.clockID  = 0;
		}

		var tDate = new Date();

		//Fix missing 0 on times less than 12
		var hours = tDate.getHours();
		var mins = tDate.getMinutes();
		if( hours < 10 )
		{
			hours = '0' + hours;
		}

		if( mins < 10 )
		{
			mins = '0' + mins;
		}

		$('#clock').html( hours + ":" + mins );

		var self = this;
		this.clockID = setTimeout( function(){ self.UpdateClock(); }, 1000*60 );
	}
	
	this.Init = function()
	{
		var self = this;
		this.clockID = setTimeout( function(){ self.UpdateClock(); }, 100 );
	}
	
	this.Kill = function()
	{
		if( this.clockID )
		{
			clearTimeout( this.clockID );
			this.clockID  = 0;
		}
	}
}