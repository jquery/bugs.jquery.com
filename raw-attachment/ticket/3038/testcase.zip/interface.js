$(document).ready(function() {
  displayElements();
});

function displayElements() {
  $(".uponload").show();
}