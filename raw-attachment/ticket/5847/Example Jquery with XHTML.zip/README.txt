Jquery or jqtouch not working with XHTML

IMPORTANT: test it on Safari with an iPhone user agent.

index_working.html : the original jqtouch version
index_problem.xhtml : modified in XHTML