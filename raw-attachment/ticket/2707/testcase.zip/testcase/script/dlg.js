function wt() {
	if (window.self.parent.$ != undefined)
		return window.self.parent;
	if (window.top.$ != undefined)
		return window.top;
	else
		if (window.self.$ != undefined)
			return window.self;
		else
			alert('wt: gave up finding jQuery - gone to pub');
}

$.dialogInit = function() {
	$("body").append('Dialog stack: <span id="dleStack">2</span>');
};
