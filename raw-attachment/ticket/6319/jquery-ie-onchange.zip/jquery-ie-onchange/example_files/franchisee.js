/*
Copyright 2010 Kahala Corp.

Javascript for franchisee portals
*/

function isInt(form_value) 
{ 
    if (form_value.match(/^\d+$/) == null) 
        return false; 
    else 
        return true; 
}

function isFloat(form_value) 
{ 
    if (isInt(form_value)) { return true;}
    if (form_value.match(/^[.\d]+$/) == null) {
    alert('invalid entry');
        return false;
    }
    else if (form_value.match(/\..*\./) != null) {
        //more than 1 period
    alert('invalid entry');
        return false;
    }
    return true;
}

$(document).ready(function() {
   $("input.qty").live('change', 
      function() {
        if (this.value != null && this.value != '' && !isInt(this.value) ) {
          //check for being an int
          $(this).addClass('error');
        }
        else {
          $(this).removeClass('error');
        }
      }
   );

   $("input.amt").live('change', 
     function() {
      if (this.value != null && this.value != '' && !isFloat(this.value) ) {
        //check for being a float value
        //if (! isFloat(this.value))
        $(this).addClass('error');
      }
      else {
        $(this).removeClass('error');
      }
     }
   );


});
