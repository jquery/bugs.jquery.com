Cross-Domain Ajax POST Patch for jQuery 1.2.5

1. function:
jQuery.Ajax can post to cross-domain

2. install:
files:patch_for_jQuery 1.2.5.txt index.html ajax_post.php
modify 'site.com' to you domain.

3. visit index.html

I'm HonestQiao
MSN:honestqiao@hotmail.com
site:http://bbs.chinaunix.net