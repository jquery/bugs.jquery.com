<?php
$content_for_layout = json_encode($_POST);
header("Pragma: no-cache");
header("Cache-Control: no-store, no-cache, max-age=0, must-revalidate");

header('Content-Type: text/html; charset=UTF-8');

if(isset($_GET['jsoncallback'])){
	$content_for_layout = sprintf('%s(%s)',$_GET['jsoncallback'],$content_for_layout);	
}
else
{
	$content_for_layout = $content_for_layout;
}

if(isset($_POST['jsoncallback']) && $_POST['jsoncallback']==$_GET['jsoncallback']){
?>
<script type="text/javascript">
	document.domain = 'site.com';
	window.parent.window.location.hash = '#' + "<?php echo str_repeat(' ',256).urlencode($content_for_layout);?>";
</script>
<?php
	}
?>