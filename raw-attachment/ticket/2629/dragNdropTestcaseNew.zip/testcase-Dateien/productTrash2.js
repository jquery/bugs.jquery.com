$(document).ready(
	function(){
		activateProductTrash();
	}
);


function activateProductTrash(){
	
	//init and enable dragable and show handles
	initDragHandlers();
//	$('div.productWrap').draggable('enable');
	$('div.dragHandle').show();
	
	initTrashBin();
	$('div#productTrash').show();	
}

function deactivateProductTrash(){
	
	//disable drag-option and hide handles
	$('div.productWrap').draggable('disable');
	$('div.dragHandle').hide();
	
	$('div#productTrash').hide();
}

function initDragHandlers(){
	$('div.productWrap').draggable({
//		handle: 'div.dragHandle',
//		revert: true,
//		start: function(){
//			$('#productTrash').fadeTo("normal", 1.0);
//			$(this).addClass('dragging');
//		},
//		stop: function(){
//			$('#productTrash').fadeTo("normal", 0.5);
//			$(this).removeClass('dragging');
//		}
	});
}

function initTrashBin(){
	// BUG in jQuery -> Position wird falsch berechnet
	$('#productTrash').droppable({
		accept: '.productWrap',
		activeClass: 'dropActive',
		hoverClass: 'dragOver',
		drop: function(ev, ui) {
			alert("Dropped!");
		}
	});
	
	

}

