jQuery(document).ready(function() {
    jQuery('select').change( function() {
            console.info('select.change()');
        });

    jQuery('select').get(0).onchange = function() {
            console.info('select.onchange');
        }
    });

