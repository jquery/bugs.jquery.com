$(document).ready(function() {
	
	$('.outer').click(function() { 
		$('.inner').animate({width: 0, paddingLeft: 0, paddingRight: 0}, 'slow' );
	});
	
});