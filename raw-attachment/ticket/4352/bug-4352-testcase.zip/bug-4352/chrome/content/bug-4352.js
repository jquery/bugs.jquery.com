var Bug4352 = {
  startup: function() {
    this.refreshInformation();
  },

  refreshInformation: function() {
    $.get("http://www.google.com.au", function(data) {
      alert(data); // works
      alert($(data).find("a")[0]); // work in firebug but throws error "div is null" in firefox extension
    });
  }
};

window.addEventListener("load", function(e) { Bug4352.startup(); }, false);
