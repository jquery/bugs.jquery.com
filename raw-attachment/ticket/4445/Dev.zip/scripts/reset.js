$(document).ready(function(){

	// Tabs
	$('#kaarten').tabs({ fxFade: true, fxSpeed: 'fast' });
	
	
	// Accordion
	$("#paginas").accordion({ header: "h3" });
	
	//show additional info
	$(".menu-f a").hover(function() {
		$(this).next("em").animate({opacity: "show", top: "-75"}, "slow");
	}, function() {
		$(this).next("em").animate({opacity: "hide", top: "-85"}, "fast");
	});
	
	//hide message_body after the first one
	$(".reaction_list .reaction_body:gt(0)").hide();
	
	//hide message li after the 3th
	$(".reaction_list li:gt(2)").hide();
	
	//toggle message_body
	$(".reaction_head").click(function(){
		$(this).next(".reaction_body").slideToggle(500)
		return false;
	});
	//collapse all messages
	$(".reaction_collapse").click(function(){
		$(".reaction_body").slideUp(500)
		return false;
	});
	//show all messages
	$(".reaction_show_all").click(function(){
		$(this).hide()
		$(".reaction_show_recent").show()
		$(".reaction_list li:gt(2)").slideDown()
		return false;
	});
	//show recent messages only
	$(".reaction_show_recent").click(function(){
		$(this).hide()
		$(".reaction_show_all").show()
		$(".reaction_list li:gt(2)").slideUp()
		return false;
	});
});