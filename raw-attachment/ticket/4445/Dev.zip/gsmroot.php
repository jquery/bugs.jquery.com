<?php
// in main
ini_set('error_reporting','2039');
	$dedir0			="";            // hier heen voor de root
	$dedir1			="includes/";   // includes
	$dedir2			="images/";     // attachement/images 
	$dedir3			="scripts/";    // scripts
	$dedir4			="manage/";     // management
	$dedir8			="assets/";   	// downloads for text
	$dedir9			="pages/";			// text
	$decolor		= "orange";			// kleurschema website
?>
