<?php
	echo "Text fp00";
?>