<?php
			echo	'<h2>'.$did.'</h2>';
			echo	'<h2>'.$admtext[prv1].'</h2>';
			echo	'<div id="paginas">';
//		echo	'<ul><li><a href="#fragment-1">'.$admtext[prv3].'</a></li>';
//		echo	'<li><a href="#fragment-2">'.$admtext[prv2].'</a></li>';
//		echo	'<li><a href="#fragment-3">'.$admtext[prv7].'</a></li></ul>';
				echo	'<div id="fragment-1"><br />';
					echo  '<h3>'.$admtext[prv3b].'</h3><div>';	
					$sql = "SELECT vid, vref, vgender, vprename, vprefix, vname, vadr1, vadr2, vadr3, vadr4, vtel1, vtel2, vtel3, vnam2, vnam3, veml, veml2, veml3, vgeb2, vgeb3, eid, vtaal, vinfo FROM svisitor WHERE vid='".$did."'";
					$res = mysql_query ($sql) or die(mysql_error());
					if(mysql_num_rows($res) > 0) { 
						list($id, $username, $gender, $prename, $prefix, $name, $adr1, $adr2, $adr3, $adr4, $tel1, $tel2, $tel3, $nam2, $nam3, $eml, $eml2, $eml3, $geb2, $geb3, $link, $taal, $info ) = mysql_fetch_row($res);
						echo '<table>';
						echo '<tbody>';
						echo '<tr><td>'.$admtext[naam].'</td><td><b>'.$gender.' '.$prename.' '.$prefix.' '.$name.'</b></td></tr>';
						if ($adr1) {echo '<tr><td>'.$admtext[adres1].'</td><td><b>'.$adr1.'</b></td></tr>';}
						if ($adr2) {echo '<tr><td></td><td><b>'.$adr2.'</b></td></tr>';}
						if ($adr3) {echo '<tr><td></td><td><b>'.$adr3.'</b></td></tr>';}
						if ($adr4) {echo '<tr><td></td><td><b>'.$adr4.'</b></td></tr>';}
						echo '<tr><td></td><td><b>--</b></td></tr>';
						echo '<tr><td>'.$admtext[mailadr].'</td><td><b>'.$username.'</b></td></tr>';
						if ($tel1) {echo '<tr><td>'.$admtext[telnr].'</td><td><b>'.$tel1.'</b></td></tr>';}
						if ($taal = "d") { 
							$hulpt = $admtext[voorktd]; 
						} else { 
							if ($taal = "f") { $hulpt = $admtext[voorktf]; } else { $hulpt = $admtext[voorktn]; } }
						if ($taal) {echo '<tr><td>'.$admtext[voorkt].'</td><td><b>'.$hulpt.'</b></td></tr>';}
						if ($info) {echo '<tr><td>'.$admtext[voorkem].'</td><td><b>'.$eml.'</b></td></tr>';}			
						if ($nam2) {
							echo '<tr><td></td><td><b>--</b></td></tr>';		
							echo '<tr><td>'.$admtext[gendermn].'</td><td><b>'.$nam2.'</b></td></tr>';
							if ($tel2) {echo '<tr><td>'.$admtext[telnr].'</td><td><b>'.$tel2.'</b></td></tr>';}
								if ($eml2) {echo '<tr><td>'.$admtext[mailadr].'</td><td><b>'.$eml2.'</b></td></tr>';}
								if ($geb2) {echo '<tr><td>'.$admtext[gebjmd].'</td><td><b>'.$geb2.'</b></td></tr>';}
						}
						if ($nam3) {
							echo '<tr><td></td><td><b>--</b></td></tr>';	
							echo '<tr><td>'.$admtext[gendervr].'</td><td><b>'.$nam3.'</b></td></tr>';
							if ($tel3) {echo '<tr><td>'.$admtext[telnr].'</td><td><b>'.$tel3.'</b></td></tr>';}
							if ($eml3) {echo '<tr><td>'.$admtext[mailadr].'</td><td><b>'.$eml3.'</b></td></tr>';}
							if ($geb3) {echo '<tr><td>'.$admtext[gebjmd].'</td><td><b>'.$geb3.'</b></td></tr>';}	
						}
							echo '<tr><td></td><td>'.$admtext[prv4].'</td></tr>';
						echo '</tbody>';
						echo '</table>';
					}
				echo '</div></div>';
				echo	'<div id="fragment-2"><br />';
					echo  '<h3>'.$admtext[prv2b].'</h3><div>';
					$sql = "SELECT seigendom.eid, egender, eprename, eprefix, enaam, eadr1, eadr2, eadr3, eadr4, email, ecomment, ocomment, wcomment, edatin, edatuit, wref FROM seigendom, swoning, seigenaar WHERE seigendom.eid = seigenaar.eid AND seigendom.wid = swoning.wid AND seigendom.eid='".$link."'";
					$res = mysql_query($sql) or die(mysql_error());	
					if(mysql_num_rows($res) > 0) { 
						$switch=1;
						while ($row = mysql_fetch_array($res, MYSQL_ASSOC)) {
							if ($switch) {
								echo '<table>';
								echo '<tbody>';
								echo '<tr><td>'.$admtext[naam].'</td><td><b>'.$row[egender].' '.$row[eprename].' '.$row[eprefix].' '.$row[enaam].'</b></td></tr>';
								if ($row[eadr1]) {echo '<tr><td>'.$admtext[adres1].'</td><td><b>'.$row[eadr1].'</b></td></tr>';}
								if ($row[eadr2]) {echo '<tr><td></td><td><b>'.$row[eadr2].'</b></td></tr>';}
								if ($row[eadr3]) {echo '<tr><td></td><td><b>'.$row[eadr3].'</b></td></tr>';}
								if ($row[eadr4]) {echo '<tr><td></td><td><b>'.$row[eadr4].'</b></td></tr>';}
								echo '<tr><td></td><td><b>--</b></td></tr>';
								if ($row[email]) {echo '<tr><td>'.$admtext[mailadr].'</td><td><b>'.$row[email].'</b></td></tr>';}
								echo '</tbody>';
								echo '</table>';	
							}
							echo  '<br /><h4>'.$admtext[prv5].'</h4>';	
							echo '<table>';
							echo '<tbody>';
							if ($row[wref]) {echo '<tr><td>'.$admtext[woning].'</td><td><b>'.$row[wref].'</b></td></tr>';}
							if ($row[edatin] != "2000-01-01") {echo '<tr><td>'.$admtext[woning].'</td><td><b>'.$row[edatin].'</b></td></tr>';}
							if ($row[edatuit] != "2050-01-01") {echo '<tr><td>'.$admtext[woning].'</td><td><b>'.$row[edatuit].'</b></td></tr>';}
							echo '</tbody>';
							echo '</table>';
						}
					}
				echo '</div></div>';
				echo	'<div id="fragment-3"><br />';
					echo  '<h3>'.$admtext[prv7b].'</h3><div>';
					$dir = $_SERVER[DOCUMENT_ROOT]."/".$dedir.$dedir9.$did."/";
					if (is_dir($dir)) {
						if ($dh = opendir($dir)) {
							while (($file = readdir($dh)) !== false) {
								$fileref = $dedir9.$did.'/'.$file;
								switch (substr($file,-3)) { 
									case "php": 
										echo '<br />'.$decr;
										include "$fileref";
										echo '<h6>'.date ("Y-m", filectime($fileref)).'</h6>'.$decr; 
										break; 
									case "xml":
										echo '<br />'.$decr;
										include "$fileref";
										echo '<h6>'.date ("Y-m", filectime($fileref)).'</h6>'.$decr; 
										break; 
									case "txt":
										echo '<br />'.$decr;
										readfile($fileref); 
										echo '<h6>'.date ("Y-m", filectime($fileref)).'</h6>'.$decr;
										break; 
									case "jpg":
										echo '<br /><img class="plaat" src="'.$fileref.'" alt="Illustration" /><br />'.$decr;
										echo '<h6>'.date ("Y-m", filectime($fileref)).'</h6>'.$decr;
										break;
									case "gif": 
										echo '<br /><img class="plaat" src="'.$fileref.'" alt="Illustration" /><br />'.$decr;
										echo '<h6>'.date ("Y-m", filectime($fileref)).'</h6>'.$decr; 
										break;
									case "pdf":
										echo '<br /><a href="'.$fileref.'"> <img alt="" src="images/ipdf.gif" style="border: 0px solid ; width: 32px; height: 32px;">'.substr($file,0,-4).'</a><br />'.$decr;
										echo '<h6>'.date ("Y-m", filectime($fileref)).'</h6>'.$decr; 
										break; 
									default: 
										if($dlevel>"3") { 
										if  (filetype($dir.$file) != "dir" ) { 
											echo '<br /><a href="'.$fileref.'">'.$file.'</a>'.$decr;	
											echo '<h6>'.date ("Y-m", filectime($fileref)).'</h6>'.$decr;
										}
									}
								}
							}
							closedir($dh);
						}
					}
				echo '</div></div>';
			echo '</div>';
?>