<?php
	require_once ( "gsmroot.php" );					
	require_once ( $dedir1."init.php" ); 
	require_once ( $dedir1."txtdefault.php" );
	require_once ( $dedir1."initfunc.php" );

	$pag 	= $_GET['pag']; 			// als pag meegestuurd
	$pag1	= $_GET['pag1'];			// als pag via form
	$pag2	= $_GET['pag2'];
	if (!$pag) { $pag = $_POST['pag']; }	
	if (!$pag) { $pag = $depage; }					// vul als empty call 
	if (!$pag1) { $pag1 = $_POST['pag1']; }
	if (!$pag2) { $pag2 = $_POST['pag2']; }

	$gsmconfig['doctype'];
?>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<title><?php echo $desite ?></title>
		<script src="<?php echo $dedir3 ?>jquery-1.3.2.min.js" 					type="text/javascript" charset="utf-8"></script>
		<script src="<?php echo $dedir3 ?>jquery-ui-1.7.custom.min.js" 	type="text/javascript" charset="utf-8"></script>
		<script src="<?php echo $dedir3 ?>jquery.form.js" 							type="text/javascript" charset="utf-8"></script>
		<script src="<?php echo $dedir3 ?>reset.js" 										type="text/javascript" charset="utf-8"></script>
		<link href= "<?php echo $dedir1 ?>stylegen.css" 								rel="stylesheet" type="text/css" media="screen" />
		<link href= "<?php echo $dedir1 ?>styleprint.css" 							rel="stylesheet" type="text/css" media="print" />
	</head>
	<body class="<?php echo $decolor ?>">
		<div id="container">
			<div id="header">
				<img src="<?php echo $dedir2 ?>logo.png" alt="Logo" />
				<h1><?php echo $desite; ?></h1>
				<h2><?php echo $admtext[adr1].'<br />'.$admtext[adr2].'<br />'.$admtext[adr3]; ?></h2>
			</div><!-- sluit header -->
			<div id="top-f">
				<div id="top-fc">
					<ul class="menu-f">
						<li>
<?php
							if ($dusername){echo '<a id="admin" href="index.php?pag=p02&pag1='.$pag.'">'.ucwords($admtext[reactadd]).'</a><em>'.$admtext[reactaddt].'</em></li><li>'; }
							if ($dlevel >3 ){ echo '<a id="admin" href="index.php?pag=p01">Administratie</a><em>Onderhoud van teksten en data</em></li><li>'; }
							if ($dusername){echo '<a id="admin" href="index.php?pag=p40">'.ucwords($admtext[nieuws]).'</a><em>'.$admtext[nieuwst].'</em></li><li>'; }
							if ($dusername){echo '<a id="admin" href="index.php?pag=p60">'.ucwords($admtext[individu]).'</a><em>'.$admtext[individut].'</em></li><li>'; }
							if ($dusername){
								echo '<a id="logout" href="index.php?pag=p01">'.$dnaam.'</a><em>'.$admtext[logoutt].'</em>';
							} else {
								echo '<a id="login" href="index.php?pag=p01">'.ucwords($admtext[login]).'</a><em>'.$admtext[logint].'</em>';
							}
?>
							</li>
					</ul>
				</div> <!-- sluit top-fc -->
			</div> <!-- sluit top-f -->
			<div id="navigation">
<?php
				$bestandn = "$dedir9$admtext[filep4]$pag$admtext[filet2]";
				$bestandn2 = "$dedir9$admtext[filep4]$depage$admtext[filet2]";
				$debugstring .= $bestandn;
				$debugstring .= $bestandn2;
				if (file_exists ($bestandn)) {				// navigation aanwezig
					include($bestandn);
				} else {
					if (file_exists ($bestandn2)) {			// default navigation aanwezig
						include($bestandn2);
					}
				}
?>
			</div> <!-- sluit navigation -->
			<div id="functions">
<?php
				$bestandf = "$dedir9$admtext[filep2]$pag$admtext[filet2]";
				$debugstring .= $bestandf;
				if (file_exists ($bestandf)) {				// functie aanwezig
					include($bestandf);
				} 
?>
			</div> <!-- sluit functions -->
			<div id="content">
<?php
				$bestand = "$dedir9$pag$admtext[filet3]";
				$debugstring .= $bestand;
				if (file_exists ($bestand)) {					// tekst aanwezig
					include($bestand);
				} 
?>
			</div> <!-- sluit content -->
			<div id="reactions">
<?php
			$bestanda = "$dedir9$admtext[filep3]$pag$admtext[filet3]";
			$debugstring .= $bestanda;
			if (file_exists ($bestanda)) {					// reacties aanwezig
?>
				<ul class="reaction_list">
					<hr>
					<h2><?php echo $admtext[reactie] ?></h2>
					<p class="reaction_buttons">
						<a href="#" class="reaction_show_all"><?php echo $admtext[reactbn] ?></a>
						<a href="#" class="reaction_show_recent"><?php echo $admtext[reactb1] ?></a>
						<a href="#" class="reaction_collapse"><?php echo $admtext[reactd] ?></a>
					</p>
					<?php include($bestanda); ?>
				</ul>
<?php			
				} else {
					echo '<h2>'.ucwords($admtext[reactno]).'</h2>';
				}
?>
			</div> <!-- sluit reactions -->
			<div id="credits">
				<h1><?php echo "$desite"; ?></h1>
				<p><?php echo "$decopyright"; ?><br />
				<?php echo "$_SERVER[SERVER_NAME]$_SERVER[PHP_SELF]"; ?></p>
			</div> <!-- sluit credits -->
			<div id="footer">
				<hr>
				<?php echo "$desite <br /> $deversie $decopyright $admtext[credits] $admtext[disclaimer]"; ?>
<?php
if($deout) {
	echo "(1) $dlevel (2) $dtaal (3) $dnaam (4) $dusername (5) $did (6) $pag (7) $pag1 (8) $pag2";
	echo $debugstring;
	reset($_POST); while (list($key, $val) = each ($_POST)) { echo $key."=".$val.", "; }
}
?>
			</div> <!-- sluit footer -->
		</div> <!-- sluit container -->
	</body>
</html>