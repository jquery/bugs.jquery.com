<?php
	$admtext['credits'] 		= "Gerard Smelt (GT). All rights reserved.";				
?>