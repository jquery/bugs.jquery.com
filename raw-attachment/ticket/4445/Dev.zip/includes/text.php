<?php
	$admtext['credits'] 		= "Gerard Smelt. All rights reserved.";				
?>