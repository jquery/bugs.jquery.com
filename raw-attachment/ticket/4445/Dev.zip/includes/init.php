<?php 
	$deout				= "1";														// debug output 	
	$dtaal				= "d";														// Taal output 	
	$desite				= "Test Application";							// applicatie  naam
	$websiteref 	= "http://www.smeltnet.eu";				// webadress
	$dedir 				= "dev/"; 												// subdirectory
	$dehome				= "index.php";										// home page
	$dehomeam			= "manage.php";										// home page
	$decr					= "\n";
	$decopyright	= "Copyright 2004 - 2009 Gerard Smelt";	
	$deversie			= "versie 16 Maart 2009";
	$dehost				= "rdbms.strato.de"; 						// hostname
	$deuser				= "U364962"; 										// username
	$depass 			= "smelt_nl"; 									// wachtwoord
	$debas 				= "DB364962"; 									// database-naam
	$depage				= "p00";												// default
	
/*

	$dehome			 	= "px.php";											// home page
	$dedir 				= "nova/"; 											// subdirectory

	$demail				= "manage@nova-park.be"; 				// afzender e-mail address
	$demails			= "syndicus@nova-park.be"; 				// afzender e-mail address
	$desite				= "Nova Park, Belgi&euml;";					// park/complex naam

	$depagetyp		= ".xml";												// filetype pages
	$depagedir		=	"pages/";											// pages directory
	$depagemenu		=	"np00";												// menu website
	$depagemeam		=	"nm00";												// menu website

	$depagediram	= "manage/";										// management directory
	$depagediram	= "images/";										// image/attachment directory
	$depagemenu		=	"np00";												// menu website
	$dehomeam		 	= "index.php";									// home page
	$deindividu		= "p70";												// pagina met speciale afhandeling	
	*/
?>