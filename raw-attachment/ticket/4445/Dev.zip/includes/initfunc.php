<?php
//initialise databases
if(mysql_connect($dehost, $deuser, $depass)) { 	//initialise database
	mysql_select_db($debas) or die(mysql_error());
} else { echo "gsm001: database!! restricted access"; }  //	exit; eruitgehaald
session_start(); 				// start of continueer sessie
if(!isset($_SESSION[suser])) {
	if(isset($_COOKIE[notitie])){ 	// cookie ?
		list($id, $wacht, $dusername, $dtaal, $dlevel, $dnaam) = explode (";", $_COOKIE["notitie"]);
		$sql = "SELECT vid, vref, vpass, vlevel, vtaal, vgender, vprename, vprefix, vname FROM  svisitor WHERE vid='".$id."'";
		$res = mysql_query ($sql) or die(mysql_error());
		if(mysql_num_rows($res) >0){
			list($id, $username, $pass, $level, $taal, $gender, $prename, $prefix, $name ) = mysql_fetch_row($res);
			if(!strcmp($wacht, $pass)) { //cookie ok
				$naam = "$gender $prename $prefix $name";
				setcookie("notitie", $id.";".$pass.";".$username.";".$taal.";".$level.";".$naam, time()+3600*24*31*6, "/"); // set cookie voor 6 maanden
				$did= $id;
				$dusername=$username;
				$_SESSION[suser] = $username;
				$dtaal=$taal;
				$dlevel=$level;
				$dnaam=$naam;
				$_SESSION[stime] = time();
				$_SESSION[smaxidle] = 60 * 60; 
			} else { setcookie("notitie", "", time(), "/");  } // weg cookie
		} else { setcookie("notitie", "", time(), "/"); } // weg cookie
	} 
} else {
	if(isset($_COOKIE["notitie"])){ 	// cookie ?
		list($did, $wacht, $dusername, $dtaal, $dlevel, $dnaam) = explode (";", $_COOKIE["notitie"]);
	}
}

//Language selection
$bestandi = $dedir1.$admtext[filep1].$dtaal.$admtext[filet2];
if (!file_exists ($bestandi) ) {include $bestandi ;}
/*	
// data processing
function data_schoon ($str, $how) {
		switch ( $how ) {
			case 'inp': // text input
				$str = str_replace ("'", "\'", htmlentities ($str));
				break;
			case 'inc': // text input geen blank
				$str = str_replace ("'", "\'", htmlentities ($str));
				if (!$str) { $str = "No naam"; }
				break;
			case 'int': // integer
				$str = (int) $str;
				break;
		}
		return $str;
	}
function data_opmaak ($str, $how) {
		switch ( $how ) {
			case 'lf': // integer
				$str = str_replace ("\n", "<br />", html_entity_decode ($str ));
				break;
			case 'in': // integer
				$str = html_entity_decode ($str );
				break;
		}
		return $str;
	}
// evaluation functions
#function valid_query ($str) 					{ return (ereg ('^[A-Za-z0-9*]+$', $str)); }
#function valid_mail ($str) 						{	return (ereg ('(^[0-9a-zA-Z_\.-]{1,}@([0-9a-zA-Z_\-]{1,}\.)+[0-9a-zA-Z_\-]{2,}$)', $str)); }
#function valid_line ($str) 						{ return (ereg ('^[A-Za-z0-9_\?. -]+$', $str)); }
#function valid_initial ($str) 				{ return (ereg ('^[A-Za-z. ]+$', $str)); }
#function valid_prefix ($str) 					{	return (ereg ('^[A-Za-z ]*$', $str)); }
#function valid_name ($str) 						{	return (ereg ('^[A-Za-z. -]+$', $str)); }
#function valid_level ($str)  					{ return (ereg ('^[0|1|2|3|4|5|6]', $str)); }	
*/
?>
