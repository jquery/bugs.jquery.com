<?php
	$admtext['credits'] 		= "Gerard Smelt (FT). All rights reserved.";				
?>