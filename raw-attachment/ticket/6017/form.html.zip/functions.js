var settings = new settings();
function show_tip(node_hovering, node_to_show, container,proper_tip, input){
	input.focused = false;
	function show_proper_tip(node_to_show, node_hovering,input){
			var offset = $(input).offset();
			$(proper_tip).html($(node_to_show).html());
			$(container).show().css({'top':offset.top-20});
	}
	$(node_hovering).hover(
		function(){
			show_proper_tip(node_to_show, node_hovering, input);
	},
		function(){
			if (!input.focused)
			$(container).hide();
	});
	$(input).focus(
			function(){
				show_proper_tip(node_to_show, node_hovering, input);
				input.focused = true;
	});
	$(input).blur(
			function(){
			$(container).hide();
			input.focused = false;
	});

}

function expandable(elem, handle){
	var expander = $('<div class="willExpand">').append($('> *',elem).not(handle));
	if ($(elem).hasClass('expanded')){}
		//$(expander).hide(); nothing to do
	else{
		$(expander).hide();
	}
	$(elem).append(expander);
	$(handle).wrapInner("<a href='#' />");
	$(handle).bind('click',function(){expander.slideToggle("fast"); $(elem).toggleClass('expanded'); return false;}) ;
	$(handle).css('paddingLeft','0');
}

var new_project = {
	round_corners_bottom:function(){
		$('#content').append('<div id="round_corners_bottom" />');
	},
	help_paragraphs : function(){
		$('p.help_text, .register_or_login label span.help_text').each(function(){
			var T = this;
			$(T).show();
			var parent = $(this).parent()
			var input = $('input, textarea',parent).get(0);
			var input_offset = $(input).position();
			if (T.nodeName.toLowerCase() == 'span')
				input_offset.top = 0;
			$(this).css({
				'position':'absolute',
				'left':'1px',
				'top':input_offset.top+1+'px',
				'paddingTop':parseInt($(input).css('paddingTop'))-1+'px',
				'paddingLeft':$(input).css('paddingLeft'),
				'paddingBottom':$(input).css('paddingBottom'),
				'paddingRight':$(input).css('paddingRight'),
				'fontWeight':'normal',
				'width':$('input').width(),
				'zIndex':10,
				'color':'#999'
			});
			if ($(input).val()!='')
				$(T).hide();
			$(T).click(function(){
				$(input).focus();
			});
			$(input).keydown(function(){
				$(T).hide();
			});
			$(input).blur(function(){
				if ($(this).val()==''){
					$(T).fadeTo('fast',1);
					$(T).show();
				}
			});
			$(input).focus(function(){
				if ($(input).val()=='')
					$(T).fadeTo('slow',0.5);
			});
		})
	},
	register_or_login : function(){
		$('.register_or_login').addClass('jsa');
		var login = $('#login.register_or_login');
		var register = $('#register.register_or_login');
		$(login).append('<p class="changer">Not registered? <span>Tell us how can we reach you!</span></p>');
		$(register).append('<p class="changer">Already a Client? <span>Please sign in!</span></p>');
		$('.register_or_login .changer').each(function(){
			var div = $(this).parent().parent();
			var T = this;
			T.padding = ($(div).height()- $(T).height())/2 - parseInt($(div).css('paddingBottom'));
			$(this).css({
				'padding-top':parseInt(T.padding)+'px',
				'padding-bottom':parseInt(T.padding)+'px'
			});
		});

		if ($(login).hasClass('open')) {$(login).parent().show();}
		else {$(login).parent().hide();}
		if ($(register).hasClass('open')) {$(register).parent().show();}
		else {$(register).parent().hide();}

		$('.register_or_login .changer span').live('click',function(){
			var parent  = $(this).parent().parent();
			$(parent).parent().hide();
			$('input', $(parent)).attr('value','');
			$('.register_or_login').each(function(){
				$(this).toggleClass('open');
				if($(this).attr('id')!=$(parent).attr('id'))
					$(this).parent().show();
			});
			return false;
		});
	},
	form_styling_hack : function(){
		$('fieldset').each(function(){
			if ($(this).css('position')=='relative'){
					$(this).wrap("<div style='position:relative' class='display_hack'>");
				}
		});
	},
	coupon : function(){
		var node = $('#coupon_li label');
		$(node).addClass('jsa');
		new expandable(node, $('span',node));
		if ($(node).hasClass('expanded'))
			$('a',node).text(settings.coupon_on);
		$('a',node).click(function(){
			new_project.coupon_text(node);
		});
	},
	coupon_text : function(node){
		if ($(node).hasClass('expanded')){
			$('a',node).text(settings.coupon_off);
			$('input',$(node).parent()).val('');
			}
		else{
			$('a',node).text(settings.coupon_on);
		}
	},
	multiFileUpload : function(){
		$('#files_li p').wrap("<div/>");
		$('#files_li').prepend("<div id='swfmessages' style='display:none'></div>"
				+"<ul id='swffiles'></ul>"
				+"<input type='hidden' name='files' id='swffile' />");
		var settings_object = {
				// File Upload Settings
				file_size_limit : "40 MB",
				file_upload_limit : "0",
				file_post_name: "filedata",
				upload_url : "/new_project/upload.php",
				flash_url : "js/swfupload.swf",
				file_size_limit : "20 MB",
				button_placeholder_id : "swfupload",
				button_width: 150,
				button_height: 28,
				button_window_mode : SWFUpload.WINDOW_MODE.TRANSPARENT,
				button_text : '<span class="buttonUpload">Attach new file</span>',
				button_text_style: ".buttonUpload { font-size: 12px; font-family:Arial; background:#ddf0f8 url(http://solvate/new_project/images/swfupload.png); color:#1b75ba; font-weight:bold}",
				button_text_left_padding : 19,
				button_text_top_padding : 9,
				button_cursor: SWFUpload.CURSOR.HAND,
				// Event Handler Settings - these functions as defined in Handlers.js
				//  The handlers are not part of SWFUpload but are part of my website and control how
				//  my website reacts to the SWFUpload events.
				file_queue_error_handler : fileQueueError,
				file_dialog_complete_handler : fileDialogComplete,
				upload_progress_handler : uploadProgress,
				upload_error_handler : uploadError,
				upload_success_handler : uploadSuccess,
				upload_complete_handler : uploadComplete,

				debug: false
				};
		swfu = new SWFUpload(settings_object);
	},
	tips : function(){
		 var tooltip_container = $('<div id="tooltip_container"></div>');
		 var proper_tip = $('<div id="proper_tip"/>')
		 $(proper_tip).appendTo(tooltip_container);
		 $(tooltip_container).appendTo('#container');
			$('#project_data > ul > li').each(function(){
				var node = this;
				if ($('div.help_text',this).get(0))
					show_tip(node, $('div.help_text',node),tooltip_container, proper_tip, $('input, textarea',node));
		});
	}
}

$(document).ready(function(){
	$('div.help_text').hide();
	new_project.form_styling_hack();
	new_project.round_corners_bottom();
	new_project.help_paragraphs();
	new_project.register_or_login();
	new_project.coupon();
	if (typeof(SWFUpload)!='undefined')
		new_project.multiFileUpload();
	new_project.tips();
});

