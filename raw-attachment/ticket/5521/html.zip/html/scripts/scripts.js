(function($)
{
    $(function()
    {
        if (jQuery.browser.safari && document.readyState != "complete"){
            setTimeout( arguments.callee, 100 );
            return;
        }
        
        // Homepage
        $("#topmenu .item").hover(function() {
            $(this).css('background-image', 'url(images/topmenu_over.gif)');
        }, function() {
            $(this).css('background-image', 'url(images/topmenu.gif)');
        });
        $("#topmenu .item_reserve").hover(function() {
            $("img", this).attr('src', 'images/topmenu_reserve_over.gif');
        }, function() {
            $("img", this).attr('src', 'images/topmenu_reserve.gif');
        });
        $("#topmenu .item_order").hover(function() {
            $("img", this).attr('src', 'images/topmenu_order_over.gif');
        }, function() {
            $("img", this).attr('src', 'images/topmenu_order.gif');
        });
        $("#topmenu .item_apartments").hover(function() {
            $("img", this).attr('src', 'images/topmenu_apartments_over.gif');
        }, function() {
            $("img", this).attr('src', 'images/topmenu_apartments.gif');
        });
        $("#topmenu .item:first").hover(function() {
            $("#topmenu .topmenu_left img").attr('src', 'images/topmenu_left_over.gif');
        }, function() {
            $("#topmenu .topmenu_left img").attr('src', 'images/topmenu_left.gif');
        });
        $("#topmenu .item:last").hover(function() {
            $("#topmenu .topmenu_right img").attr('src', 'images/topmenu_right_over.gif');
        }, function() {
            $("#topmenu .topmenu_right img").attr('src', 'images/topmenu_right.gif');
        });
    });
})(jQuery);
