jQuery().ready(function(){
	$("#contain1").hover(function(){$('#rollover1').slideDown('fast')},function(){$('#rollover1').slideUp('fast')});
	$("#contain2").hover(function(){$('#rollover2').slideDown('fast')},function(){$('#rollover2').slideUp('fast')});
	$("#contain3").hover(function(){$('#rollover3').slideDown('fast')},function(){$('#rollover3').slideUp('fast')});
})
