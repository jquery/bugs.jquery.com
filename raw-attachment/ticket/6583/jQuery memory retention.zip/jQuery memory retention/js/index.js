function get() {
	$.ajax({
		url: "file:///thisshouldfail",
		timeout: 1000,
		error: function(XMLHttpRequest, textStatus, errorThrown) {
			setTimeout(get, 100);
		}
	});
}

$(document).ready(function() {
	get();
});