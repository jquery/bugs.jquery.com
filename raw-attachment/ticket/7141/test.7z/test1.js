$(document).ready(function(){
	$('#test').hide();
	$('#test').show();
});