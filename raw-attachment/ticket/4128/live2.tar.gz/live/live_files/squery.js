/**********************
*  sQuery.js
*  version: 0.0.2
***********************/


/*****************************
 *
 *        S E L E C T
 *   @todo: add the hader
 ****************************/

var squerySelectOn = 'squery-select-on';
var squerySelectSettings = {
  innerHTML: '&nbsp;'
}
jQuery.fn.squerySelect = function(settings) {

    var settings = jQuery.extend(squerySelectSettings, settings || {});

    this.filter('select').each(function() {

        if ( this.className.match('squeried') ) return;

        // read class
        _className = this.className.replace(/\bsquery\b/g, '');

        // main elements
        wrapper = document.createElement('div');
        hader = document.createElement('div');
        hader.className = 'squery-header';
        hader.value = document.createElement('span');
        hader.toggle = document.createElement('a');
        hader.toggle.href = 'javascript:void(0);';
        hader.toggle.innerHTML = settings.innerHTML;
        ul = document.createElement('ul');

        // hader
        hader.value.innerHTML = this.options[this.selectedIndex].innerHTML;
        hader.appendChild(hader.value);
        hader.appendChild(hader.toggle);
        hader.tabIndex = 0;
        hader.ul = hader.toggle.ul = ul;
        hader.onkeydown = hader.toggle.onclick = function() {
            $(this).parents('div.squery-select-wrapper').addClass('squery-open');
            this.ul.focus();
        }
        this.hader = hader;

        // ul
        ul.tabIndex = 0;
        ul.onkeydown = selectKeyboardHandler;
        ul.onblur  = function() { $(this).parents('div.squery-select-wrapper').removeClass('squery-open'); }
        ul.select = this;

        // option -> li
        for (i = 0; i < this.length; i++) {
            li = document.createElement('li');
            li.select = this;
            li.option = this.options[i];
            li.innerHTML = this.options[i].innerHTML;
            li.index = i;
            li.onclick = squerySelectToggle;
  
            if (li.option.selected) li.className = squerySelectOn;
  
            this.options[i].li = li;
            this.options[i].firstChar = this.options[i].text.substr(0, 1).toLowerCase();
  
            ul.appendChild(li);
        }

        // wrapper
        wrapper.className = 'squery-select-wrapper ' + _className;

        // constructor
        $(this)
        .addClass('squeried')
        .wrap(wrapper)
        .after($('<div class="squery-options"/>').append(ul))
        .after(hader)
        .change(squerySelectUpdate);

    });

    return this;
}

function squerySelectToggle(event) {
    select = event.target.select;
    if (select.multiple) {
        event.target.option.selected = !event.target.option.selected;
    } else {
        select.selectedIndex = event.target.index;
    }
    $(select).change();
    select.hader.focus();
}

function squerySelectUpdate() {
    for (i = 0; i < this.length; i++) {
        $(this.options[i].li).condClass(this.options[i].selected, squerySelectOn);
    }
    this.hader.value.innerHTML = this.options[this.selectedIndex].innerHTML;
}


function selectKeyboardHandler(event) {

    select = event.target.select;

    // up arrow
    switch (event.which) {
        case 38 : // up
            select.selectedIndex = (select.selectedIndex + select.length - 1) % select.length;
            break;
        case 40 : // down
            select.selectedIndex = (select.selectedIndex + 1) % select.length;
            break;
        case 36 : // home
            select.selectedIndex = 0;
            break;
        case 35 : // end
            select.selectedIndex = select.length - 1;
            break;
        case  9 : // tab
        case 27 : // esc
        case 13 : // enter
            select.hader.focus();
            break;
        default:
            // a..z
            if ( (event.which | 32) >= 97 && (event.which | 32) <= 122) {
                c = String.fromCharCode(event.which).toLowerCase();
                i = (select.selectedIndex + 1) % select.length;
                while ( i != select.selectedIndex) {
                    if ( c == select.options[i].firstChar ) {
                        select.selectedIndex = i;
                        break;
                    } else {
                        i = (i + 1) % select.length;
                    }
                }
            }
    }

    $(select).change();

    // no page scrolling
    if (event.which != 9 ) return false;
}


/*****************************
 *
 *  F O R M   T O O L B O X
 *
 *****************************/

// returns true of checkbox is checked
jQuery.fn.checked = function()
{
    return this[0].checked;
}
// chech checkbox unless check(false)
jQuery.fn.check = function(check)
{
    if (check !== false) {
        this.attr('checked', 'checked');
    } else {
        this.removeAttr('checked');
    }
    return this;
}
// uncheck a checkbox
jQuery.fn.uncheck = function()
{
    return this.check(false);
}

/******************************
 *
 *         S T R I N G
 *
 *****************************/
String.prototype.reverse = function() {
    return this.split('').reverse().join('');
}
/******************************
 *
 *          A R R A Y
 *
 *****************************/
// adds or removes a value from an array
Array.prototype.toggle = function(value) {
    if ( (index = jQuery.inArray(value, this)) != -1) {
      this.splice(index, 1);
    } else {
      this.push(value);
    }
    return this;
}
/******************************
 *
 *           C S S
 *
 *****************************/
jQuery.fn.hoverClass = function(className) {
    className = className || 'hover';
    this.hover(
        function() { $(this).addClass(className); },
        function() { $(this).removeClass(className); }
    );
    return this;
}

// depending on condition, adds or removes class className
jQuery.fn.condClass = function(condition, className) {
  if (condition)
    this.addClass(className);
  else
    this.removeClass(className);
}

