/*
 By Diego A. - www.fyneworks.com
 This is a modified version of the star rating plugin from:
	http://www.phpletter.com/Demo/Jquery-Star-Rating-Plugin/
	
	For full details and history, see:
	http://www.fyneworks.com/jquery/star-rating/
*/
// ORIGINAL COMMENTS:
/*************************************************
	This is hacked version of star rating created by <a href="http://php.scripts.psu.edu/rja171/widgets/rating.php">Ritesh Agrawal</a>
	It thansform a set of radio type input elements to star rating type and remain the radio element name and value,
	so could be integrated with your form. It acts as a normal radio button.
	modified by : Logan Cai (cailongqun[at]yahoo.com.cn)
	website:www.phpletter.com


************************************************/
/*
*	convert a set of radio buttons to star rating type of question
*/

jQuery.fn.rating = function(settings) {
	settings = jQuery.extend({
		 cancel:'Cancel Rating'
	}, settings);
 
	// multiple star ratings on one page
	var groups = {};
 
	var prevElem = null;
	var valueElem = null;
 //var container = jQuery(this);
 var CancelElem = null;
	
	var event = {
		fill: function(n, el, style){ // fill to the current mouse position.
		 //LOG(style || 'star_hover', arguments);
			var stars = jQuery(groups[n].valueElem).siblings('.star');
			var index = stars.index(el) + 1;
			jQuery(stars)
				.children('a').css('width', '100%').end()
				.removeClass('star_hover').removeClass('star_on')
				.lt(index).addClass( style || 'star_hover' ).end();
//				.lt(index).addClass('star_on').end();
		},
		drain: function(n) { // drain all the stars.
		 //LOG(groups);
		 //LOG([ 'drain', n, groups[n] ] );
			var stars = jQuery(groups[n].valueElem).siblings('.star');
			jQuery(stars)
				.filter('.star_on').removeClass('star_on').end()
				.filter('.star_hover').removeClass('star_hover').end();
		},
		reset: function(n){ // Reset the stars to the default index.
		 //LOG(groups);
		 //LOG([ 'reset', n, groups[n] ] );
			var stars = jQuery(groups[n].valueElem).siblings('.star');
			jQuery(stars).lt(groups[n].currentValue).addClass('star_on').end();
		}
	};
 
 this.each(function (i)
					{
						
						var n = this.name;
						if(!groups[n]) groups[n] = {count:0, currentValue: 0};
						groups[n].count += 1;
						i = groups[n].count - 1;
						
						if(i == 0)//prepend cancel option at the begining
						{
												
							groups[n].valueElem = jQuery('<input type="hidden" name="' + this.name + '" value="" >');
							jQuery(this).before(groups[n].valueElem);
								
								
								var CancelElem = jQuery('<div class="cancel"></div>');
								prevElem = CancelElem;
								jQuery(this).before(prevElem);	

										jQuery(CancelElem)
													.mouseover(function(){
															event.drain(n);
															//-->hack<--
															jQuery(this).addClass('star_on');
													})
													.mouseout(function(){
															event.reset(n);
														//	jQuery(this).removeClass('star_on');
													})
													.click(function(){
															groups[n].currentValue = 0;//jQuery(this).children('a').attr('title');
															$(groups[n].valueElem).val(groups[n].currentValue);
															event.drain(n);
															return false;
													});				
						};
						
						//insert rating option right after preview element
						preElemTemp  = jQuery('<div class="star"><a  class="sync" href="javascript:;" title="' + this.value + '">' + this.value + '</a></div>');
						jQuery(prevElem).after(preElemTemp);
						jQuery(preElemTemp)
								.mouseover(function(){
											event.drain(n);
											event.fill(n, this);
										
									})
									.mouseout(function(){
											event.drain(n);
											event.reset(n);
											
									})
									.click(function(){
											groups[n].currentValue = jQuery(this).children('a').attr('title');
											jQuery(groups[n].valueElem).val(groups[n].currentValue);
											event.drain(n);
											//event.reset();
											event.fill(n, this);
											if ($('input[@name=comment_rating]').length) {
                        $('input[@name=comment_rating]')[0].checked=false; // pour decocher le note z�ro
											}
											//alert($(this).parent().attr('id'))
											
											//-->hack<--
											if($("#NminStars")){ //RA
											 $("#NminStars").find(".cancel").removeClass('star_on');
											}			
											if($("#5_stars")){ //COMMENT SHOP
											 $("#5_stars").find(".cancel").removeClass('star_on');
											}
									});						
						
						//LOG(['###', n, this.checked, groups[n].initial]);
						if(this.checked) groups[n].initial = preElemTemp;
						
						prevElem = preElemTemp;
						preElemTemp = null;
						
						//remove this checkbox
						$(this).remove();
						if(i + 1 == this.length){    
							event.reset(n);									
						}

				}
				
   );
	 
		// initialize groups...
		for(n in groups){
			if(groups[n].initial){
			 $(groups[n].initial).each(function(){
     event.fill(n, this, 'star_on');
					groups[n].currentValue = $(this).children('a').attr('title');
					$(groups[n].valueElem).val(groups[n].currentValue);
				});
			}
  };
		
		return this; // don't break the chain...
};
