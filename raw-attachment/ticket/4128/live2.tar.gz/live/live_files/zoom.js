var loader_file = 'ajax-loader-trans.gif';
var zoomInit = 0;
var zoom_store = new Array();
var zoomIE6 = navigator.userAgent.match('MSIE 6');

/*
 * Il y a un problème d'affichage quand on annule le zoom alors qu'on est au chargement
 *  - on est au loader, donc l'image finale se charge
 *  - on dezoome alors qu'on est encore sur le loader, donc tout est .hide()
 *  - l'image finale termine son chargement, et #zoomContainer est .show(), donc l'image s'affiche quand même
 *  - donc pour éviter ça, je rajoute une variable pour savoir si on a dézoomé ou non
 */
var has_been_unzoomed = false;

/**
 * Effectue un zoom sur une image
 */
function zoom(id, rel)
{
  has_been_unzoomed = false;
  if (zoomInit == 0) {
    var $body = $('body');
    $body.append(
      '<div id="zoomBackground" onclick="unzoom()"></div>' +
      '<div id="zoomContainer" onclick="unzoom()"></div>' +
      '<style>#zoomBackground { background-color : #222; opacity : 0.8; filter:alpha(opacity=80); z-index : 10000; position : absolute; top : 0; left : 0; width : 100%; height : ' + $body.height() + 'px }</style>'
    );

    zoom_add_image('loader', $('#js_urlimg').text() + loader_file );
    zoomInit = 1;
  }
  $('#zoomBackground').show();

  // affiche l'image si elle est en stock, sinon elle est ajoutée
  var img = zoom_display_stored(id);
  if (img == 'undefined') {
    zoom_display_stored('loader');
    zoom_add_image(id, rel);
  }
  return false;
}

/**
 * Dézoom une image
 */
function unzoom()
{
  $('#zoomContainer').html('&nbsp;').hide();
  $('#zoomBackground').hide();
  has_been_unzoomed = true;
  if ( zoomIE6 ) {
    display_all_select();
  }
}

/**
 * Ajoute une image
 */
function zoom_add_image(index, src)
{
  // chargement de l'image
  var image = document.createElement('img');
  image.setAttribute('src', src);
  image.onload = function() { zoom_display_image(image) };

  // corrige un bug IE qui n'appelle pas onload si l'image est dans le cache
  if (image.complete) { zoom_display_image(image); }

  // bug ie6
  if ( zoomIE6 ) {
    hide_all_select();
  }

  // ajout de l'image au tableau de cache
  var img = new Array();
  img[0] = index;
  img[1] = image
  zoom_store.push(img);
}

/**
 * Calcule les dimensions à afficher pour l'image et sa position
 */
function zoom_pos_image(image)
{
  // calcul de la taille affichée
  var windowWidth = $(window).width();
  var windowHeight = $(window).height();

  var maxWidth = windowWidth - 300;
  var maxHeight = windowHeight - 200;
  var width = image.width;
  var height = image.height;

  if (width > maxWidth) {
    height = height * maxWidth / width;
    width = maxWidth;
  }

  if (height > maxHeight) {
    width = width * maxHeight / height;
    height = maxHeight;
  }

  var zoomLeft = (windowWidth - width) / 2;
  var zoomTop = (windowHeight - height) / 2;

  $(image).css({
     position: 'fixed', top: zoomTop + 'px', left: zoomLeft + 'px',
     zIndex: '10001', width: width + 'px', height: height + 'px',
     border: '4px solid #fff', '-moz-border-radius': '5px',
     backgroundColor: '#fff'
  });

  // bug IE 6
  if ( zoomIE6 ) {
    $(image).css({
       position : 'absolute',
       top : document.documentElement['scrollTop'] + zoomTop + 'px'
    });
  }
}

/**
 * Affiche l'image
 */
function zoom_display_image(image)
{
  zoom_pos_image(image);
  $('#zoomContainer').html(image);
  if (!has_been_unzoomed) {
    $('#zoomContainer').show();
  }
}

/**
 * Retourne une image si celle-ci a déjà été enregistrée, 'undefined' sinon
 */
function zoom_display_stored(index)
{
  count = zoom_store.length;
  for (var i = 0; i < count; i++)
  {
    if (zoom_store[i][0] == index) {
      zoom_display_image(zoom_store[i][1]);
    }
  }

  return 'undefined';
}


function hide_all_select(){
  $('#A select').hide();
}

function display_all_select(){
  $('#A select').show();
}
