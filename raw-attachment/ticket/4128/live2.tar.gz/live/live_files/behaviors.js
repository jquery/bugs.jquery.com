// liens ou formulaire a envoyer/suivre apres animation
var formToSubmit = 0;
var linkToFollow = 0;
/**
 * Applique les comportements javascript une fois la page completement chargee.
 */
$(document).ready(function() {
  // les comportements globaux
  addAutomaticBehaviors();

  $(this)
  .ajaxStart(showAjaxLoader)
  .ajaxComplete(addAutomaticBehaviors)
  .ajaxStop(hideAjaxLoader)
  .ajaxError(showAjaxError);

  //Pour ouvrir A si  on clique sur A lors d'inscription  Refs#602
  $('div.borderMiddle').click( function() {
    if ($('#BackToShopping').length) {
      $('#C.js_async div.js_content').load(UrlRoot + '/member/fakeLayout', null, openA);
    } 
  } );

  // formulaire de recherche qui doit agrandir la partie A si elle est fermee
  $('#search_input_form').submit( function(){
    if (aActive) return true;
    formToSubmit = this;
    openA(undefined, goToForm);
    return false;
  });

  // active les differents liens en rapport avec le slide
  $('#aMiddleWrapper').add('#anse').add('#A').click(openA);
  $('#C').click(openC);

  // les bulles
  $('body').click(hideTooltip);
  $('#bulle div.fermer').click(hideTooltip);

  // clean anchors on title's page
  document.title = document.title.replace(/#.*/, '');
  setTimeout("document.title = document.title.replace(/#.*/, '');", 1500);

  // makes the contribution % visible on ie6 in the 'myContributions' tab..
  $('div.contributionPercent').css('zIndex', '999');

  // makes all the fieldsets in the footer the same height
  $('#footer fieldset').alignBottoms();
  
  
  $('a.js_link_internal').live('click', jsLinkInternal);
});

/**
 * Regroupe toutes les fonctions qui doivent etre appelés apres le
 * chargement de pages ou de chargment Ajax.
 */
function addAutomaticBehaviors() {

  // les bulles
  bindInfoIcones();

  // active le lazyClick
  $('a.js_lazyClick').jsClass('js_lazyClick').lazyClick();

  // fixes ie6 attribute selectors
  fixIe6AttributeSelection();

  // france, uk, de tout en haut du select
  // ne peut etre appelé depuis un template a cause de l'iframe
  movePreferredCountriesUp('livecountry');

  $('#popette a').click(popetteAsyncLinks);

  // problem with live('click') , put back when fixed in jQuery
  $('a.js_link_popette').jsClass('js_link_popette').click(popette_open_dialog);

  $('#C a').each(function() {
    if ( !this.className.match('js_link_internal') ) {
      $(this).click(function() {
        if (aActive) return true;
        linkToFollow = this;
        openA(undefined, goToLink);
        return false;
      });
    }
  });

  makeAsyncForms();

  // permet que les liens actifs aient un contour bleu
  $('a.js_contour').click(function() {
    $('a.js_contour').removeClass('contour');
    $(this).addClass('contour');
  });

  $('select').squerySelect();

  $('.Collapsible > div.Header').click(toggleCollapsible);
  $('.Collapsible > div.Header > a.Title').click(openCollapsible);
  
}

/**
 * Affiche et cache le loader global
 */
function showAjaxLoader() { $('#ajaxLoader').show(); }
function hideAjaxLoader() { $('#ajaxLoader').hide(); }

/**
 * Affiche et cache le message d'erreur ajax
 */
function showAjaxError(error, settings, request) { 
  hideAjaxLoader();
  /* uncoment to show ajax error message
  txtError  = 'Erreur de chargement ajax de l\'url suivante : \n' + request.url ;
  txtError += '\n\nCode error : ' + settings.status;
  txtError += '\nMessage : ' + settings.statusText;
  alert(txtError);
  */
  $('#ajaxError').show(); 
  setTimeout("hideAjaxError()", 2000);
}
function hideAjaxError() { $('#ajaxError').fadeOut(1000); }

/*************************************
 *
 *    T H E    W I S H L I S T
 *
 ************************************/

// misc variables
var wishlistAnimId = null;
var wishlistDivs = null;
var productHovered = false;
var productDragged = false;
var $block_W;

function add_behaviors()
{
  // si le pave wishlist n'existe pas, on n'active pas le drag&drop
  if (!$('#block_W').size()) return false;

  // Comportements associes au glisser / deposer

  $('img.js_draggable')
  .css('cursor', 'move')
  .each(function() {
    makeDraggable(this.id);
  })
  .hover(
    function() { productHovered = true; startWishlistAnim() },
    function() { productHovered = false; stopWishlistAnim() }
  );

  $('#pave_wishlist.js_droppable').Droppable({
      accept:       'product',
      activeClass:  'activeWishlist',
      hoverClass:   'hoverWishlist',
      tolerance:    'intersect',
      onDrop:       function (dragged) {
                      // hack to hide the object that's supposed to revert
                      // to it's original position, then show it again
                      $('#dragHelper').hide().show(1000);
                      // TODO : Security risk ??
                      addProductToWishlist(dragged);
                    }
  });

  wishlistDivs = $('#block_W div.yellowBlock').add('#DropProduct');
}

function makeDraggable(id)
{
  if ($('#'+id).DraggableDestroy) { $('#'+id).css('position', 'static').DraggableDestroy(); }
  $('#'+id).Draggable({
    revert: true,
    fx: 300,
    ghosting: true,
    opacity: 0.8,
    onStart: clearCss,
    onStop:  function() {
      // in explorer Draggables are only draggable once
      // @see http://dev.jquery.com/ticket/1806

      if (jQuery.browser.msie)
      {
        setTimeout('makeDraggable("' + id + '")', 400);
      }
      productDragged = false;
      stopWishlistAnim();
    }
  });
}


// adds animation on the pavewishlist when gragging
function stopWishlistAnim() {
  if (productDragged || productHovered) return;
  clearTimeout(wishlistAnimId);
  $('#block_W').removeClass('floating').css('position', 'static');
  wishlistDivs.removeClass('on');
}

function startWishlistAnim() {
  _offsetTop = (window.pageYOffset !== undefined) ? window.pageYOffset : document.documentElement['scrollTop'];
  _wishlistTop = $('#block_W').offset().top;

  // while dragging, moves the wishlist down if hidden
  if (_offsetTop > _wishlistTop)
  {
    $('#block_W')
    .css({position: 'absolute', right: '20px', top: (30 + _offsetTop) + 'px'})
    .addClass('floating');
  }

  //start animation of the pave wishlist and add class
  wishlistAnimOn();
}

function wishlistAnimOn() {
  wishlistDivs.addClass('on');
  clearTimeout(wishlistAnimId);
  wishlistAnimId = setTimeout('wishlistAnimOff()', 400);
}
function wishlistAnimOff() {
  wishlistDivs.removeClass('on');
  clearTimeout(wishlistAnimId);
  wishlistAnimId = setTimeout('wishlistAnimOn()', 400);
}

// hides the arrow that's on the image background
function clearCss(img)
{
  productDragged = true;
  startWishlistAnim();
}

function addProductToWishlist(dragged)
{
  addProductToWishlistById($(dragged).attr('id').match(/\d+/));
}

function addProductToWishlistById(id)
{
  var action_uri = UrlRoot + '/member/addProductToLists?product_id=' + id;
  popette_open_dialog(action_uri)
}

/**
 * Submit/follow le formulaire/lien s'il y en a un en attente
 */
function goToForm(){
  if(formToSubmit){
    formToSubmit.submit();
  }
}
function goToLink(){
  if(linkToFollow){
    document.location.href = linkToFollow;
  }
}

/**
 * Inflechis le comportement des liens de la page en fonction de leur classe css :
 *
 *  - jsLinkInternal : effectue une requete asynchrone vers l'url designee par l'attribut "href" du lien
 *                     et affiche la reponse dans l'element designe par l'attribut "x-lbi-target" du lien.
 *                     Il est aussi possible de definir un callback qui sera appele une fois le lien charge.
 *                     eg. :  * <a href="/some/url" class="js_link_internal" x-lbi-target="#C" x-lbi-callback="my_callback">
 *
 *  - js_link_popette :  effectue une requete asynchrone vers l'url designee par l'attribut "href" du lien et
 *                       affiche la reponse dans une fenetre modale (a l'aide de jqModal).
 *
 * Le comportement des autres liens n'est pas modifie.
 */

function jsLinkInternal(event)
{
  // shortcut
  $this = $(this);

  /*
   * On determine quelle element HTML va accueillir la reponse a la requete asynchrone.
   * Les liens designant une cible inexistante sont ignores.
   */
  var response_target  = $this.xLbiTarget();
  var $responseTarget;


  // si pas de target on voit si le lien a un parent de class js_async et js_content
  if (response_target == '')
  {
    if ($this.parents('div.js_content').size())
    {
      $responseTarget = $this.parents('div.js_content');
    }
  }
  else
  {
    $responseTarget = $(response_target);
  }

  if ($responseTarget && $responseTarget.size())
  {
    // Si la methode choisie est POST, on passe un payload
    // non nul a jquery.load, pour forcer l'utilisation de POST
    var payload = null;
    if ( $this.attr('x-lbi-method') == 'POST' ) payload = {};

    // on cache les bulles
    if ( !$this.hasClass('js_keep_tooltip') ) hideTooltip();

    // permet d'ajouter une confirmation
    var rep_confirm = true;
    if ( ( confirmation = $this.xLbiConfirm()) != undefined) {
      rep_confirm = confirm(confirmation);
    }

    if ( rep_confirm ) {
      // clear all timout (news ...)
      if ( $this.attr('x-lbi-cleartimeout') ) {
        clearAllNewsTimeout();
      }
  
      // ie6 does not support anchors in ajax calls
      var url  = $this.attr('href').replace(/#(.*)$/, '');
      var hash = $this.attr('href').match(/#(.*)$/);

      $responseTarget.load(url, payload, function() {
        // s'assurer que A ou C sont ouverts si nécessaire
        if      ( $responseTarget.parents('#C').size() ) openC();
        else if ( $responseTarget.parents('#A').size() ) openA();
        // session expiree en partie C
        $('#C div.popetteContent h1').text('Session expired');
        // permet de prendre en compte les ancres
        if ( hash ) location.href = location.href.replace(/#(.*)$/, '') + hash[0];
      });

      event.preventDefault();
    }
  }
}

/**
 * @see http://www.malsup.com/jquery/form/#api
 */
function makeAsyncForms()
{
  $('form').each(function(i,n) {
    var $this = $(this);
    var response_target = $this.xLbiTarget();

    if (response_target != '' && $(response_target).size())
    {
      options = { target: response_target,
                  beforeSubmit : function() {
                      if ($this.xLbiConfirm() && !testForm()) return false;

                      return true;
                    }
                }
      $this.ajaxForm(options);
    }
  });
}

jQuery.fn.xLbiTarget = function() {
  if ( 0 === this.size() ) return '';
  matches = this[0].className.match(/\bx_lbi_target_([^ ]*)/);
  if ( matches ) {
    return Base64.decode(matches[1]);
  }
  else return '';
}
jQuery.fn.xLbiConfirm = function() {
  return this.attr('x-lbi-confirm');
  if ( 0 === this.size() ) return '';
  matches = this[0].className.match(/\bx_lbi_confirm_([^ ]*)/);
  if ( matches ) {
    return Base64.decode(matches[1]);
  }
  else return '';
}

/************************************************************
 *
 *                     P O P E T T E
 *
 ***********************************************************/


/**
 * @see http://dev.iceburg.net/jquery/jqModal/README
 */
function popette_open_dialog(href)
{
  href = typeof(href) == 'object' ? $(this).attr('href') : href;
  var options = {
    ajax:     href,
    target:   'div.pcontent',
    modal:    true,
    onShow:   function(hash) {  },
    onLoad:   function(hash) {
      popetteAsyncForms();
      popettePostProcess();
      hash.w.show();
      
      // un autre bug ie ...
      if ($.browser.msie) $('#A').css('top', '1px').css('top', 0);
    }
  }

  $('#popette').jqm(options).jqmShow();
  return false;
}


/**
 * @desc  fonction executée apères l'afficahge d'une popette
 *        Permet de la center, etc...
 */
function popettePostProcess()
{

  $('#popette').center(0, -35);
  $('body > div.jqmOverlay').css('cursor', 'default');

  /* focus ff2*/
  if (checkBrowser('ff2'))
  {
    $("#popette input:password")
    .add("#popette input:text")
    .add("#popette textarea")
    .focus( function() { $(this).addClass('ff2hover')    } )
    .blur(  function() { $(this).removeClass('ff2hover') } )
  }
}

// add a close button to the popette
function popetteClose()
{
  $('#popette div.pcontent').html('');
  if ($('#doRedirect').attr('x-lbi-c') == 'true') {
    document.location = document.location;
  } else {
    $('#popette').jqmHide();
  }

  return false;
}

/**
 * @desc  Permet la fermeture d'une popette apres x millsecondes
 */
function autoClosePopette(ms) {
  setTimeout("$('#popette input.ok').trigger('click')", ms);
}


/**
 * @see http://www.malsup.com/jquery/form/#api
 */
function popetteAsyncForms()
{
  $('#popette form').not('form.sync').each(function(i, form) {
    options = {
      target: '#popette div.pcontent',
      beforeSubmit : function() {
        if ($(form).attr('x-lbi-confirm') && !testForm()) return false;
        $(form).find('input[type=submit]').attr('disabled', 'disabled').css('cursor', 'wait');
        return true;
      },
      success: popetteAsyncForms
    }
    $(this).ajaxForm(options);

  });
}

function popetteAsyncLinks()
{
    $this = $(this);
    if (!this.className.match('sync') && $this.attr('target') != '_blank') {
      $('#popette div.pcontent').load($this.attr('href'), null, popetteAsyncForms);
      return false;
    }
}



/*********************************
 *
 *  Code dedie au volet glissant
 *
 *********************************/
// tailles min et max
var aMinWidth = 307;
var aMaxWidth = 610;
var cMinWidth = 205;
var cMaxWidth = 495;
var cCacheMaxWidth = 60;
var anseMinLeft = 70;
var anseMaxLeft = 227;
var rechercheMinWidth = 100;
var rechercheMaxWidth = 185;

// durée du slide
var slideDuration = 1000;

// ouvre A
function openA(e, callback) {
  // skip propagation of event which caused tkt #120
  if (e) {
    e.cancelBubble = true;
    if (e.stopPropagation) e.stopPropagation();
  }
  // si deja ouvert, on sort
  if (aActive) return;

  // si on ouvre A, on ferme C
  closeC();

  // desactive les labels de la page profile
  $('#C div.conteneurInscription label').one('click', function () { openC(); return false; });

  // slide

  $('#A').animate({width: aMaxWidth}, slideDuration);
  $('#bulle').hide();
  $('#cache').animate({width: 0}, slideDuration);
  $('#anse').animate({left: anseMaxLeft}, slideDuration, undefined, callback);

  $('div.formScat').each(function(i,e) {
    if ($(this).css('visibility') == 'visible'){
      $(this).show('slow');
    }
  })

  if ($('#BackToShopping').length != 0) {
     $('#C.js_async div.js_content').load(UrlRoot + '/member/fakeLayout', null, openA);
  }

  aActive = true;
}

function closeA() {
  // si deja ferme, on sort
  if (!aActive) return;


  $('#bulle').hide();
  $('#A').animate({width: aMinWidth}, slideDuration);
  $('#cache').animate({ width: aMinWidth}, slideDuration);
  $('#anse').animate({left: anseMinLeft}, slideDuration);

  $('div.formScat').each(function(i,e){
    if($(this).css('visibility') == 'visible'){
      $(this).hide('slow')
    }
  })

  aActive = false;
}

function openC() {

  // deja ouvert, on sort
  if (cActive) return;

  // si on ouvre C, il faut fermer A
  closeA();

  // active les labels de la page profile
  $('#C div.conteneurInscription label').unbind('click');

  // slide
  $('#C').animate({width: cMaxWidth}, slideDuration);
  $('#cacheC').animate({width: 0}, slideDuration);

  cActive = true;
}

function closeC() {

  // si deja ferme, on sort
  if (!cActive) return;

  // slide et quitte le ta profil si ouvert
  $('#C').animate({width: cMinWidth}, slideDuration, leaveProfileTab);
  $('#cacheC').animate({width: cCacheMaxWidth}, slideDuration);

  cActive = false;
}

function closeAC() { 
  closeA(); 
  closeC(); 
}

// ouver ou ferme A
function toggleA() {
  if (aActive) { closeA(); } else { openA(); }

  return false;
}

// ouver ou ferme A
function toggleC() {
  if (cActive) { closeC(); } else { openC(); }

  return false;
}

// permet de switcher vers MySpace si on n'y est pas
function leaveProfileTab() {
  if (!($('#C input[name=in_my_space]').size()) && linkToFollow==0) {
    loadMySpace();
  }
}

// chage l'onglet mySpace
function loadMySpace() {
  if($('#C div.js_content').size()) {
    $('#C div.js_content').load(UrlRoot + '/member/', null);
  }
}


/**
 * Creation de l'url de recherche marchand a partir du formulaire
 */
function changeCatUrl(form)
{
  // on rajoute le texte a recherche
  url = form.action + "?qs=" + $('#qs').val();

  // si une categorie principale est selectionnee
  // on la rajoute avec toutes les souscategories
  mainCategory = $('#primaryCategories').val();
  if (mainCategory)
  {
    subCategories = [mainCategory];
    $('input[id^=c_' + mainCategory + '_]').filter('[checked]').each(function() {
      subCategories.push(this.name.match(/\d+/));
    });
    url += '&cats=' + subCategories.join(',');
  }
  // on redirige
  location.href = url +'#contributionBox';
}

/*
 * Cette fonction renvoie une chaine de toutes les id de categories cochees du formulaire
 * Utiliser en remplacement de changeCatUrl
 */
function changeCats(form)
{
  // recup de tout ce qui est coche dans le formulaire,
  //il faudrait pouvoir affiner a uniquement ce qui s'appelle cats[aaaaa]
  var cats = $('#' + form.id + ' :checked');
  if (cats.length > 0) {
    var str_cat = '';
    for (i = 0; i < cats.length; i++)
    {
      str_cat += parseInt(cats[i].name.substr(5, 6)) + ',';
      cats[i].checked = false;
    }
    str_cat = str_cat.substr(0, str_cat.length - 1);
    form.cats.value = str_cat;
  }
}

// flash Function
function flash2JS_GoToUrl(url){
  linkToFollow = url+'#mainTabs';
  if (aActive) goToLink();
  openA(undefined, goToLink);
}
function flash2JS_addToWishList(pid){
  popette_open_dialog(UrlRoot + '/member/addProductToLists/' + pid);
}

// move the formScats out of the table to allow them
// to display on top of the flash
function fixFormScats() {
  $('div.formScat')
  .css('visibility', 'hidden')
  .each(function() {
    if($('#primaryCategories').length)
    {
      _offset = $('#stringMore').offset();
      y = 15;
      x = (jQuery.browser.msie ? 6 : 0);
    }
    else
    {
      _offset = $(this).offset();
      y = 6;
      x = (jQuery.browser.msie ? 6 : 60);
    }

    $('body').prepend(this);
    this.style.position = 'absolute';
    this.style.top = parseInt(_offset.top + y) + 'px';
    this.style.left = parseInt(_offset.left+ x) + 'px';
    this.style.margin = '0';
  });
}

// Because ie6 lacks attibute selection we transform all
// <input type="xxx" class="yyy" ...> in <input type="xxx" class="yyy type_xxx" ....>
function fixIe6AttributeSelection() {
  $('input').each(function() {
    $(this).addClass('type_' + this.type);
  });
}


// scroll to top
function scrollToTop() {
  window.scrollTo(0,0);
  openC();
}

// function pour trier les payes dans un select
function movePreferredCountriesUp(selectId) {
  $select = $('#'+selectId);
  if (!$select.size() || $select.hasClass('js_processed')) return;

  $select.addClass('js_processed');

  selectedIndex = $select[0].selectedIndex;
  $option = $('option[value=]', $select);
  $('<option value=""></option>')
  .add('#'+selectId+' option[value=DE]')
  .add('#'+selectId+' option[value=GB]')
  .add('#'+selectId+' option[value=FR]')
  .each(function() {
    $(this).clone().insertAfter($option);
  });

}

/****************************************
* partie historique recherche principale
*****************************************/


function getBaseURI(){
  if( window.document.baseURI != null ) return window.document.baseURI;
  if( document.getElementsByTagName('base').href != null ) return document.getElementsByTagName('base').href;
  if( document.getElementsByTagName('base')[0].href != null ) return document.getElementsByTagName('base')[0].href;
  return '';
}

/****************************
 *         B U L L E
 ***************************/

// timer pour la fermeture automatique
var showTooltipTimer;
var hideTooltipTimer;


jQuery.fn.tooltip = function(layout, skipClick, cssClass) {
  var skipClick = skipClick || false;
  var cssClass = cssClass || 'bulle';
  return this.each(function() {
    if (!this.className.match('js_tooltipped')) {

      $(this)
      .addClass('js_tooltipped')
      .hover(
        function() {
          showTooltipTimer = setTimeout('showTooltip()', 200);
          clearTimeout(hideTooltipTimer);
          prepareTooltip(this, layout, cssClass);
        },
        function() {
          clearTimeout(showTooltipTimer);
          hideTooltipTimer = setTimeout('hideTooltip()', 2000);
        }
      );
      if (!skipClick) {
        $(this).click(function() {
          clearTimeout(showTooltipTimer);
          showTooltip();
          return false;
        });
      }
    }
  });
}


/**
 * prepare le contenu et l'emplacememnt de la bulle
 *
 * @param: layout la configuration de la bulle
 *
 *      left:   le decalage du cote gauche par rapport a l'icone
 *      right:  le decalage du cote droit par rapport a l'icone
 *      bottom: le decalage du bas par rapport a l'icone
 *      top:    le decalage du haut par rapport a l'icone
 *
 *      on a (soit left, soit right) et (soit top, soit bottom)
 *
 */
function prepareTooltip(i, layout, cssClass) {
  // for some reasons, uner ie, we need to reset these values
  $('#bulle').css({ left: '', top: '', bottom: '', right: ''});
  $('#bulle')[0].className = cssClass;
  // charge le contenu et affecte le width
  $('#bulle td.bc').width(layout.width).html('').append($('div.bcontent > *', i).clone(true));
  // calcule la position de la bulle
  bLeft = $(i).offset().left + ( layout.left != undefined ? layout.left : layout.right - $('#bulle').width() );
  bTop =  $(i).offset().top  + ( layout.top  != undefined ? layout.top  : layout.bottom - $('#bulle').height() );
  // est-ce qu'elle est dehors ?
  //if ( bLeft + $('#bulle').width() > $('body').width()) bLeft = bLeft - $('#bulle').width() - 20;
  // place la bulle
  $('#bulle').css({ left: bLeft, top:  bTop });

  // ferme la bulle au bout de 5 secondes
  return false;
}

function showTooltip() {
  clearTimeout(showTooltipTimer);
  $('#bulle').show();
}
function hideTooltip() {
  clearTimeout(showTooltipTimer);
  clearTimeout(hideTooltipTimer);
  $('#bulle').hide();
}
function openBinvite() {
  $('#bInvite')
  .addClass('open')
  .animate({height: 225}, 200);
}
function closeBinvite() {
  $('#bInvite')
  .removeClass('open')
  .animate({height: 42}, 10);
}

//laisser le bulle affiche tant qu'on est dessus

$(function(){
  $('#bulle').hover(
    function(){
      clearTimeout(hideTooltipTimer);
    },
    function(){
      hideTooltipTimer = setTimeout('hideTooltip()', 5000);
    });
})

// affecte les differents comportements
function bindInfoIcones() {
  $('div.js_achat_direct').tooltip({ left: -276, top:     6, width: 211 });
}
/* cette fonction est temporaire - enfin ..j'espere :D refs #847 */
function htmlEntitesDecode(string){
  return string.replace(/&agrave;/g, 'à');
}

function loadUrlInAsyncC(url){
  if ( $('#C.js_async div.js_content').size() ) {
    $('#C.js_async div.js_content').load(url);
  } else {
    location.href = url;
  }
}


/**
 * Permet d'afficher un produit d'une liste dans la page members->listes
 * @param string id l'id html, comprend deux entiers, le premier étant l'id du produit, le second l'id de la liste
 */
function getProduct(id)
{
  // si le produit déjà affiché est le même que celui demandé, on ne fait rien
  if (currentId == id) return false;

  currentId = id;

  ids = id.match(/(\d+)_(\d+)/);
  listId = ids[2];
  productId = ids[1];


  // cache bulle si ouverte
  hideTooltip();

  // cache le produit déjà ouvert
  $('.conteneurCategory[id!=list_' + listId + '] .productInfos').html('').hide();

  // affiche le produit demandé
  $products.filter('.current').removeClass('current');
  $('#' + id).addClass('current');

  $currentInfos = $('#list_' + listId + ' .productInfos');
  $currentInfos.listId = listId;

  $currentInfos.html('').show();
  $currentInfos.load(product_url + productId);
}

function initMembersContributions()
{
  // add class when we hover tr
  $('div.cInfos').hoverClass('cInfosHover');

  // change cursor and add toggle on content
  $('div.cContent').prev('div.cInfos')
  .css('cursor', 'pointer')
  .click(function() {
    membersShowContribution($(this));
    return false;
  });
}

function membersShowContribution($object)
{
  $('div.cContent:visible').not($object.next('div.cContent')).hide();
  $object.next('div.cContent').slideToggle(400);
}


/**
 * @todo : ie , safari , opera ...
 * @param stringBrowser : ff2 , ff3
 * @return
 */
function checkBrowser(stringBrowser){
  //mozilla true  1.9
  switch (stringBrowser) {
    case 'ff2':
      return ($.browser.mozilla && $.browser.version.indexOf('1.8') > -1)
    case 'ff3':
      return ($.browser.mozilla && $.browser.version.indexOf('1.9') > -1)
    default:
      return false;
  }
}

/************************************************************
 *
 *             j Q u e r y    E x t e n s i o n s
 *
 ***********************************************************/

/**
 * @desc  Permet de modifier le nom d'une class css utilisée
 *        par jQuery pour que l'element ne soit pas retraité
 *        Ex: $('a.js_link_internal').jsClass('js_link_internal').click(...)
 *
 */
$.fn.jsClass = function(cssClass) {
  return this.each(function() { this.className = this.className.replace(cssClass, '__'+cssClass); });
}

/**
 * @desc  Active le lazyClick qui permet d'emuler un click 
 *        en passant sur un lien
 */
var lazyClickTimer = null;
var lazyClickCounter = 0;

$.fn.lazyClick = function() {
  return this.each(function() {
    $this = $(this);

    // rajouter un attribut pour permettre l'appel dans le timer
    $this
    .attr('lazyClick', ++lazyClickCounter)
    .hover(
      function() {
        lazyClickTimer = setTimeout("$('[lazyClick=" + $(this).attr('lazyClick') + "]').click();", 700);
      },
      function() {
        clearTimeout(lazyClickTimer);
      }
    );
  })
}

/**
 * @desc  Permet de rajouter une class hover sur un element 
 *        au passage de la souris, chose pas possible sous ie6
 *
 * @param String className   la classe a ajouter (default=hover)
 */
jQuery.fn.hoverClass = function(className) {
    className = className || 'hover';
    this.hover(
        function() { $(this).addClass(className); },
        function() { $(this).removeClass(className); }
    );
    return this;
}


/**
 * @desc  Centers a given window relatively to the screen
 
 *
 * @param int leftOffset décalage horizontal
 * @param int topOffset  décalage vertical
 */
$.fn.center = function(leftOffset, topOffset) {
  // do we shift the dialog in one direction ?
  leftOffset = leftOffset ? leftOffset : 0;
  topOffset = topOffset ? topOffset : 0;

  // distance to the top of the visible area
  _offsetTop = (window.pageYOffset !== undefined) ? window.pageYOffset : document.documentElement['scrollTop'];

  // compute browsing and dialog size
  _browserHeight = document.documentElement.clientHeight;
  _browserWidth = document.documentElement.clientWidth;

  _dialogHeight = this.height() + topOffset;
  _dialogWidth  = this.width()  + leftOffset;

  // compute left and top margin (we only center vertically if dialog smaller than window)
  _marginTop  = _browserHeight > _dialogHeight ? ( _browserHeight - _dialogHeight ) / 2 : 0 ;
  _marginLeft = ( _browserWidth  - _dialogWidth  ) / 2;

  // center
  this.css('top', _offsetTop + _marginTop + topOffset);
  this.css('left', _marginLeft + leftOffset);

  return this;
}

/**
 * @desc  Makes all block level elements the same height
 */
jQuery.fn.alignBottoms = function() {
  var _maxHeight = 0;
  this.each(function() { _maxHeight = Math.max(_maxHeight, $(this).height()); });
  this.height(_maxHeight);
  return this;
}


/**
 * @desc  Permet d'avoir un texte par défaut dans le input
 */
jQuery.fn.titleOnBlur = function() {
  return this
  .each(function()  { if( this.value == '')   this.value = this.title; $(this).addClass('EmptyInput'); } )
  .blur(function()  { if (this.value == '') { this.value = this.title; $(this).addClass('EmptyInput'); } })
  .focus(function() { if (this.value == this.title) { this.value = ''; $(this).removeClass('EmptyInput'); }})
}


function toggleCollapsible() {
  $this = $(this);
  $Collapsible = $this.parents('.Collapsible');
  $Collapsible.toggleClass('UnCollapsed');

  $Collapsibles = $this.parents('.Collapsibles');
  if ( $Collapsibles.size() )
  {
    $Collapsibles.find('.Collapsible').not($Collapsible).removeClass('UnCollapsed');
  }
  return false;
}

function openCollapsible() {
  $this = $(this);
  $Collapsible = $this.parents('.Collapsible');
  $Collapsible.addClass('UnCollapsed');

  $Collapsibles = $this.parents('.Collapsibles');
  if ( $Collapsibles.size() )
  {
    $Collapsibles.find('.Collapsible').not($Collapsible).removeClass('UnCollapsed');
  }
  return false;
}


/**
*
*  Base64 encode / decode
*  http://www.webtoolkit.info/
*
**/

var Base64 = {

    // private property
    //_keyStr : "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
    _keyStr : "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_=",

    // public method for decoding
    decode : function (input) {
        var output = "";
        var chr1, chr2, chr3;
        var enc1, enc2, enc3, enc4;
        var i = 0;

        input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");

        while (i < input.length) {

            enc1 = this._keyStr.indexOf(input.charAt(i++));
            enc2 = this._keyStr.indexOf(input.charAt(i++));
            enc3 = this._keyStr.indexOf(input.charAt(i++));
            enc4 = this._keyStr.indexOf(input.charAt(i++));

            chr1 = (enc1 << 2) | (enc2 >> 4);
            chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
            chr3 = ((enc3 & 3) << 6) | enc4;

            output = output + String.fromCharCode(chr1);

            if (enc3 != 64) {
                output = output + String.fromCharCode(chr2);
            }
            if (enc4 != 64) {
                output = output + String.fromCharCode(chr3);
            }

        }

        output = Base64._utf8_decode(output);

        return output;

    },


    // private method for UTF-8 decoding
    _utf8_decode : function (utftext) {
        var string = "";
        var i = 0;
        var c = c1 = c2 = 0;

        while ( i < utftext.length ) {

            c = utftext.charCodeAt(i);

            if (c < 128) {
                string += String.fromCharCode(c);
                i++;
            }
            else if((c > 191) && (c < 224)) {
                c2 = utftext.charCodeAt(i+1);
                string += String.fromCharCode(((c & 31) << 6) | (c2 & 63));
                i += 2;
            }
            else {
                c2 = utftext.charCodeAt(i+1);
                c3 = utftext.charCodeAt(i+2);
                string += String.fromCharCode(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));
                i += 3;
            }

        }

        return string;
    }

}
