<?php

	header("Pragma: no-cache");
	mt_srand(time());
	echo mt_rand(0, 100);		
?>