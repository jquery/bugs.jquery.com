/*
	Javascript Window Manager in combinatie met jQuery 1.1.2
	(c) 2007 Giel Berkers
*/

$(function(){
	// Z-index van de windows:
	z=100;
	// Eerst ervoor zorgen dat een single-click niet het venster opent:
	// Aktie geven op doubleclick:
	$('div.icon').dblclick(function(){
		z++;
		$('#desktop').append('<div class="window w'+z+'"></div>');
		url = $('var.url', this).text();
		titel = $('var.titel', this).text();
		var w = $('div.w'+z);
		nx = ($('#desktop').width()/2)-(w.width()/2);
		ny = ($('#desktop').height()/2)-(w.height()/2);
		w.css('left', nx);
		w.css('top', 100);
		w.css('z-index', z);
		w.append('<div class="topbar">'+titel+'<a href="" class="closewindow">[X]</a></div><div class="content"></div>');	
		$('div.content', w).load(url);
		$('div.topbar a.closewindow', w).click(function(){
			w.remove();
			return false;
		});
		// containment-bug in IE7 helaas :-(
		w.Draggable({handle: '.topbar', zIndex: z, containment: 'parent', onStart: function(){
			// Z-index omhoogzetten:
			z++;
			$(this).css('z-index', z);
		}});
		w.click(function(){
			z++;
			w.css('z-index', z);
		});
		return false;
	});	
});