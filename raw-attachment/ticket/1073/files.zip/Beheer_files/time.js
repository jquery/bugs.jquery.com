/*
	Tijd
	(c) 2007 Giel Berkers
	--
	Dit script zorgt er tevens voor dat er iedere 30 seconde een refresh wordt uitgevoerd naar de server om de sessie levend te houden.
*/
function refreshsession() {
	$('#time').load('inc/heartbeat.php');
	setTimeout('refreshsession()', 30000);
}

$(function(){
	refreshsession();
});