/*
	Icon manager
	(c) 2007 Giel Berkers
*/

function rearangeicons(){
	var top = 20;
	var left = 20;
	var maxw = $('#desktop').width()-80;
	var maxh = $('#desktop').height();
	$('div.icon').each(function(){
		$(this).css('left', left+'px');
		$(this).css('top', top+'px');
		left+=80;
		if(left>maxw) {
			left = 20;
			top += 70;
		}
	});
}

$(function(){
	rearangeicons();
	// Icons opnieuw indelen als het venster wordt geresized:
	$(window).resize(function(){rearangeicons();});
});