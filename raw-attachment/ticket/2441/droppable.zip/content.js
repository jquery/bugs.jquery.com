$(document).ready(
		function()
		{
			initDraggables();
			initDroppables();
		}
);

var counter = 1;

function initDraggables() {
	$('.block').draggable(
			{
				helper: 'clone',
				revert: true
			}
	);
}

function initDroppables() {
	$('.block').droppable(
		{
			accept : '.block',
			tolerance: 'pointer',
			over : function(obj) {
				$('.block').removeClass('droppable-hover');
				$(this).addClass('droppable-hover');
				$('#debug').prepend('moving into '+$(this).attr('id')+'<br />');
			},
			out : function(obj, ui) {
				$('.block').removeClass('droppable-hover');
				$('#debug').prepend('leaving '+$(this).attr('id')+'<br />');
			},
			drop : function(ev, ui) {
				$('.block').removeClass('droppable-hover');
				$('#debug').prepend('dropped in '+$(this).attr('id')+'<br />');
			}
	});
}