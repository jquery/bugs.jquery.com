/**
 * Interface Elements for jQuery
 * Autoscroller
 * 
 * http://interface.eyecon.ro
 * 
 * Copyright (c) 2006 Stefan Petre
 * Dual licensed under the MIT (MIT-LICENSE.txt) 
 * and GPL (GPL-LICENSE.txt) licenses.
 *   
 *
 */
eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--){d[e(c)]=k[c]||e(c)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('1.2={j:8,5:8,3:8,6:u,E:k(r,s,6,o){1.2.5=r;1.2.3=s;1.2.6=q(6)||u;1.2.j=A.F(1.2.m,q(o)||B)},m:k(){z(i=0;i<1.2.3.C;i++){a(!1.2.3[i].4){1.2.3[i].4=1.w(1.b.n(1.2.3[i]),1.b.v(1.2.3[i]),1.b.G(1.2.3[i]))}e{1.2.3[i].4.t=1.2.3[i].g;1.2.3[i].4.l=1.2.3[i].f}a(1.2.5.9&&1.2.5.9.I==N){7={x:1.2.5.9.L,y:1.2.5.9.J,c:1.2.5.9.p.c,d:1.2.5.9.p.d}}e{7=1.w(1.b.n(1.2.5),1.b.v(1.2.5))}a(1.2.3[i].4.t>0&&1.2.3[i].4.y+1.2.3[i].4.t>7.y){1.2.3[i].g-=1.2.6}e a(1.2.3[i].4.t<=1.2.3[i].4.h&&1.2.3[i].4.t+1.2.3[i].4.d<7.y+7.d){1.2.3[i].g+=1.2.6}a(1.2.3[i].4.l>0&&1.2.3[i].4.x+1.2.3[i].4.l>7.x){1.2.3[i].f-=1.2.6}e a(1.2.3[i].4.l<=1.2.3[i].4.H&&1.2.3[i].4.l+1.2.3[i].4.c<7.x+7.c){1.2.3[i].f+=1.2.6}}},M:k(){A.D(1.2.j);1.2.5=8;1.2.3=8;z(i K 1.2.3){1.2.3[i].4=8}}};',50,50,'|jQuery|iAutoscroller|elsToScroll|parentData|elToScroll|step|elementData|null|dragCfg|if|iUtil|wb|hb|else|scrollLeft|scrollTop|||timer|function||doScroll|getPositionLite|interval|oC|parseInt|el|els||10|getSizeLite|extend|||for|window|40|length|clearInterval|start|setInterval|getScroll|wh|init|ny|in|nx|stop|true'.split('|'),0,{}))
