"use strict";
/*jslint white: true, browser: true, onevar: true, undef: true, nomen: true, eqeqeq: true, plusplus: true, bitwise: true, regexp: true, newcap: true, immed: true, strict: true */
//if (!document.getElementByID) {
//		Go to no_javascript_found.html
//		For now, just do an alert
//		alert("Your browser does not support all the features this page requires.  Please upgrade to a more current browser.  Firefox, Chrome, and Safari are recommended.");
//	}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}

function title3() {
		$("#line3-text").delay(20000).animate({left: '-=157%'}, 6000);
		}

function title2() {
		$("#line2-text").delay(9000).fadeTo(4000, 1.0).delay(1000).fadeTo(1000, 0.0).fadeTo(4000, 1.0, title3());
		}

function resetHawksWorld(){
			$("#hawks-world").stop().fadeTo(500, 0.0).animate({right: "-95%"},0);
		}
		
function resetSample() {
			$("#reviews").stop().fadeTo(500, 0.0).animate({right: "-95%"}, 0);
		}

function resetHome() {
			$("#reviews").stop().fadeTo(500, 0.0).animate({right: "-95%"}, 0);
			$("#hawks-world").stop().fadeTo(500, 0.0).animate({right: "-95%"}, 0);
			$("#skyline").stop().fadeTo(1500, 1.0);
			$("#sky").stop().fadeTo(1500, 1.0);
			$("#moon").stop().fadeTo(1500, 1.0);
			$("#somewhere").stop().fadeTo(1500, 1.0);
			$("#line2-text").stop().fadeTo(1500, 1.0);
			$("#line3-text").stop().fadeTo(1500, 1.0);
			$("#changefontup").stop().fadeTo(0, 0.0);
			$("#changefontdn").stop().fadeTo(0, 0.0);
			$("#changefontdefault").stop().fadeTo(0, 0.0)()
		}

//
//	Font resize code
var H, W, Factor=1, B4=false, Warn=true;

function once()			// Executed only once.
{	if (B4) return;
	B4 = true;
	window.onresize=resize;
	resize();
}

// Match body font to size of window.

function Finc()			// Increase by 10%
{	Factor *= 1.1;
	if (Factor > 5) Factor = 5;
	resize();
}

function Fdec()			// Decrease by 10%
{	Factor *= .9;
	if (Factor < .5) Factor = .5;
	resize();
}

function Fset()			// Reset factor
{	Factor = 1;
	resize();
}

// Percent of width: Define the size of "1.0em"

function resize()	// Set font relative to window width.
{	if (window.innerWidth)
		W = window.innerWidth;
	else
		W = document.body.clientWidth;

//   P =  Math.floor (W/33);				// ca. 3 percent constant
//		Original font sizing math function
//P =  Math.floor (Factor*(8+W/65));		// Linear function
	P =  Math.floor (Factor*(W/65-6));		// Linear function

//	Original minimum font size
//	if (P<10)P=10;							// Smallest size.
	if (P<8)P=8;							// Smallest size.
	document.body.style.fontSize=P + 'px';
//	Set individual elements as below
//		document.getElementById('reviews').style.fontSize=P + 'px';
//		document.getElementById('hawks-world').style.fontSize=P + 'px';
//		document.getElementById('menu').style.fontSize=P + 'px';

show = document.getElementById('warning');
	Ratio = window.screen.availWidth/W;
//	alert("W="+W+"  Ratio"+Ratio+"   P"+P);
	if (Warn && Ratio > 1.5)				// Show Warn?
		Warn = false;
	if (Warn)
		show.style.display = 'block';
	else
		show.style.display = 'none';
}
//	End font resize code

window.onload = preLoad;

function preLoad () {
		$.preloadCssImages();
}

$(document).ready(function () {
}); // document ready function end

//		Page load animations
function openAnimation () {
		$("#line2-text").hide().stop();
		$("#line3-text").stop();
		$("#book-cover").hide().stop();
		$("#reviews").hide().stop();
		$("#screen").hide().stop();
		$("#menu").hide().stop();
		$("#changefontup").hide().stop();
		$("#changefontdn").hide().stop();
		$("#changefontdefault").hide().stop();


//		Perform Title Animations
		$("#reticle").hide().stop().delay(200).fadeTo(2000, 1.0);
//		$("#reticle").hide().stop().delay(200).fadeIn(2000);
		$("#skyline").hide().stop().delay(750).fadeTo(7000, 1.0);
		$("#moon").hide().stop().delay(1500).fadeTo(8000, 1.0);  //
		$("#sky").hide().stop().delay(4000).fadeTo(4500, 1.0);
		$("#somewhere").hide().stop().delay(5000).fadeTo(7000, 1.0,title2());
		$("#menu").hide().stop().delay(9500).fadeTo(1000, 1.0);  //


//		Activate Home frame
		$("#home-button").click(function(){
			 resetHome();
		});

//		Activate hawks-world frame
		$("#hawks-world-button").click(function(){
			$("#skyline").stop().fadeTo(1500, 0.20);
			$("#sky").stop().fadeTo(1500, 0.20);
			$("#moon").stop().fadeTo(1500, 0.20);
			$("#somewhere").stop().fadeTo(1500, 0.20);
			$("#line2-text").stop().fadeTo(1500, 0.20);
			$("#line3-text").stop().fadeTo(1500, 0.20);
			$("#hawks-world").stop().animate({right: "10%"},0).fadeTo(3000, 1.0);
			$("#changefontup").stop().fadeTo(3000, 1.0);
			$("#changefontdn").stop().fadeTo(3000, 1.0);
			$("#changefontdefault").stop().fadeTo(3000, 1.0);
			resetSample();
		});

//		Activate The_Book frame
		$("#the-book-button").click(function(){
			$("#skyline").stop().fadeTo(1500, 0.20);
			$("#sky").stop().fadeTo(1500, 0.20);
			$("#moon").stop().fadeTo(1500, 0.20);
			$("#somewhere").stop().fadeTo(1500, 0.20);
			$("#line2-text").stop().fadeTo(1500, 0.20);
			$("#line3-text").stop().fadeTo(1500, 0.20);
			$("#reviews").stop().animate({right: "10%"},0).fadeTo(3000, 1.0);
			$("#changefontup").stop().fadeTo(3000, 1.0);
			$("#changefontdn").stop().fadeTo(3000, 1.0);
			$("#changefontdefault").stop().fadeTo(3000, 1.0);
			resetHawksWorld();
		});

//		Activate Excerpt frame
		$("#excerpt-button").click(function(){
			$("#skyline").stop().fadeTo(1500, 0.20);
			$("#sky").stop().fadeTo(1500, 0.20);
			$("#moon").stop().fadeTo(1500, 0.20);
			$("#somewhere").stop().fadeTo(1500, 0.20);
			$("#line2-text").stop().fadeTo(1500, 0.20);
			$("#line3-text").stop().fadeTo(1500, 0.20);
			$("#reviews").stop().animate({right: "10%"},0).fadeTo(3000, 1.0);
			$("#changefontup").stop().fadeTo(3000, 1.0);
			$("#changefontdn").stop().fadeTo(3000, 1.0);
			$("#changefontdefault").stop().fadeTo(3000, 1.0);
			resetHawksWorld();
		});

//		Activate Font Size Increase
		$("#changefontup").click(function (){
			 Finc();
		});

//		Activate Font Size Decrease
		$("#changefontdefault").click(function (){
			 Fset();
		});

//		Activate Font Size Decrease
		$("#changefontdn").click(function (){
			 Fdec();
		});
}



//		This function works to test for preloading readiness
function loadImages() {
if (document.getElementById) { // DOM3 = IE5, NS6
		document.getElementById('hidepage').style.visibility = 'hidden';
		openAnimation ();
		}
else {
	if (document.layers) { // Netscape 4
		document.hidepage.visibility = 'hidden';
		openAnimation ();
		}
else { // IE 4
	document.all.hidepage.style.visibility = 'hidden';
		openAnimation ();
		}
	}
}


